# 1 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c"
# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h" 1
 
 












 











# 103 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





















































		


		typedef unsigned size_t;
	
	
        
	

















	

 



















 
 
 
 
 


 
 
 
 
 
 














int     lr_start_transaction   (char * transaction_name);
int lr_start_sub_transaction          (char * transaction_name, char * trans_parent);
long lr_start_transaction_instance    (char * transaction_name, long parent_handle);
int   lr_start_cross_vuser_transaction		(char * transaction_name, char * trans_id_param); 



int     lr_end_transaction     (char * transaction_name, int status);
int lr_end_sub_transaction            (char * transaction_name, int status);
int lr_end_transaction_instance       (long transaction, int status);
int   lr_end_cross_vuser_transaction	(char * transaction_name, char * trans_id_param, int status);


 
typedef char* lr_uuid_t;
 



lr_uuid_t lr_generate_uuid();

 


int lr_generate_uuid_free(lr_uuid_t uuid);

 



int lr_generate_uuid_on_buf(lr_uuid_t buf);

   
# 273 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int lr_start_distributed_transaction  (char * transaction_name, lr_uuid_t correlator, long timeout  );

   







int lr_end_distributed_transaction  (lr_uuid_t correlator, int status);


double lr_stop_transaction            (char * transaction_name);
double lr_stop_transaction_instance   (long parent_handle);


void lr_resume_transaction           (char * trans_name);
void lr_resume_transaction_instance  (long trans_handle);


int lr_update_transaction            (const char *trans_name);


 
void lr_wasted_time(long time);


 
int lr_set_transaction(const char *name, double duration, int status);
 
long lr_set_transaction_instance(const char *name, double duration, int status, long parent_handle);


int   lr_user_data_point                      (char *, double);
long lr_user_data_point_instance                   (char *, double, long);
 



int lr_user_data_point_ex(const char *dp_name, double value, int log_flag);
long lr_user_data_point_instance_ex(const char *dp_name, double value, long parent_handle, int log_flag);


int lr_transaction_add_info      (const char *trans_name, char *info);
int lr_transaction_instance_add_info   (long trans_handle, char *info);
int lr_dpoint_add_info           (const char *dpoint_name, char *info);
int lr_dpoint_instance_add_info        (long dpoint_handle, char *info);


double lr_get_transaction_duration       (char * trans_name);
double lr_get_trans_instance_duration    (long trans_handle);
double lr_get_transaction_think_time     (char * trans_name);
double lr_get_trans_instance_think_time  (long trans_handle);
double lr_get_transaction_wasted_time    (char * trans_name);
double lr_get_trans_instance_wasted_time (long trans_handle);
int    lr_get_transaction_status		 (char * trans_name);
int	   lr_get_trans_instance_status		 (long trans_handle);

 



int lr_set_transaction_status(int status);

 



int lr_set_transaction_status_by_name(int status, const char *trans_name);
int lr_set_transaction_instance_status(int status, long trans_handle);


typedef void* merc_timer_handle_t;
 

merc_timer_handle_t lr_start_timer();
double lr_end_timer(merc_timer_handle_t timer_handle);


 
 
 
 
 
 











 



int   lr_rendezvous  (char * rendezvous_name);
 




int   lr_rendezvous_ex (char * rendezvous_name);



 
 
 
 
 
char *lr_get_vuser_ip (void);
void   lr_whoami (int *vuser_id, char ** sgroup, int *scid);
char *	  lr_get_host_name (void);
char *	  lr_get_master_host_name (void);

 
long     lr_get_attrib_long	(char * attr_name);
char *   lr_get_attrib_string	(char * attr_name);
double   lr_get_attrib_double      (char * attr_name);

char * lr_paramarr_idx(const char * paramArrayName, unsigned int index);
char * lr_paramarr_random(const char * paramArrayName);
int    lr_paramarr_len(const char * paramArrayName);

int	lr_param_unique(const char * paramName);
int lr_param_sprintf(const char * paramName, const char * format, ...);


 
 
static void *ci_this_context = 0;






 








void lr_continue_on_error (int lr_continue);
char *   lr_unmask (const char *EncodedString);
char *   lr_decrypt (const char *EncodedString);


 
 
 
 
 
 



 







 















void   lr_abort (void);
void lr_exit(int exit_option, int exit_status);
void lr_abort_ex (unsigned long flags);

void   lr_peek_events (void);


 
 
 
 
 


void   lr_think_time (double secs);

 


void lr_force_think_time (double secs);


 
 
 
 
 



















int   lr_msg (char * fmt, ...);
int   lr_debug_message (unsigned int msg_class,
									    char * format,
										...);
# 513 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_new_prefix (int type,
                                 char * filename,
                                 int line);
# 516 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_log_message (char * fmt, ...);
int   lr_message (char * fmt, ...);
int   lr_error_message (char * fmt, ...);
int   lr_output_message (char * fmt, ...);
int   lr_vuser_status_message (char * fmt, ...);
int   lr_error_message_without_fileline (char * fmt, ...);
int   lr_fail_trans_with_error (char * fmt, ...);

 
 
 
 
 
# 540 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

 
 
 
 
 





int   lr_next_row ( char * table);
int lr_advance_param ( char * param);



														  
														  

														  
														  

													      
 


char *   lr_eval_string (char * str);
int   lr_eval_string_ext (const char *in_str,
                                     unsigned long const in_len,
                                     char ** const out_str,
                                     unsigned long * const out_len,
                                     unsigned long const options,
                                     const char *file,
								     long const line);
# 574 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_eval_string_ext_free (char * * pstr);

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
int lr_param_increment (char * dst_name,
                              char * src_name);
# 597 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"













											  
											  

											  
											  
											  

int	  lr_save_var (char *              param_val,
							  unsigned long const param_val_len,
							  unsigned long const options,
							  char *			  param_name);
# 621 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_save_string (const char * param_val, const char * param_name);



int   lr_set_custom_error_message (const char * param_val, ...);

int   lr_remove_custom_error_message ();


int   lr_free_parameter (const char * param_name);
int   lr_save_int (const int param_val, const char * param_name);
int   lr_save_timestamp (const char * tmstampParam, ...);
int   lr_save_param_regexp (const char *bufferToScan, unsigned int bufSize, ...);

int   lr_convert_double_to_integer (const char *source_param_name, const char * target_param_name);
int   lr_convert_double_to_double (const char *source_param_name, const char *format_string, const char * target_param_name);

 
 
 
 
 
 
# 700 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_save_datetime (const char *format, int offset, const char *name);









 











 
 
 
 
 






 



char * lr_error_context_get_entry (char * key);

 



long   lr_error_context_get_error_id (void);


 
 
 

int lr_table_get_rows_num (char * param_name);

int lr_table_get_cols_num (char * param_name);

char * lr_table_get_cell_by_col_index (char * param_name, int row, int col);

char * lr_table_get_cell_by_col_name (char * param_name, int row, const char* col_name);

int lr_table_get_column_name_by_index (char * param_name, int col, 
											char * * const col_name,
											size_t * col_name_len);
# 761 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int lr_table_get_column_name_by_index_free (char * col_name);

 
 
 
 
# 776 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
int   lr_zip (const char* param1, const char* param2);
int   lr_unzip (const char* param1, const char* param2);

 
 
 
 
 
 
 
 

 
 
 
 
 
 
int   lr_param_substit (char * file,
                                   int const line,
                                   char * in_str,
                                   size_t const in_len,
                                   char * * const out_str,
                                   size_t * const out_len);
# 800 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
void   lr_param_substit_free (char * * pstr);


 
# 812 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"





char *   lrfnc_eval_string (char * str,
                                      char * file_name,
                                      long const line_num);
# 820 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


int   lrfnc_save_string ( const char * param_val,
                                     const char * param_name,
                                     const char * file_name,
                                     long const line_num);
# 826 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lrfnc_free_parameter (const char * param_name );







typedef struct _lr_timestamp_param
{
	int iDigits;
}lr_timestamp_param;

extern const lr_timestamp_param default_timestamp_param;

int   lrfnc_save_timestamp (const char * param_name, const lr_timestamp_param* time_param);

int lr_save_searched_string(char * buffer, long buf_size, unsigned int occurrence,
			    char * search_string, int offset, unsigned int param_val_len, 
			    char * param_name);

 
char *   lr_string (char * str);

 
# 929 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"

int   lr_save_value (char * param_val,
                                unsigned long const param_val_len,
                                unsigned long const options,
                                char * param_name,
                                char * file_name,
                                long const line_num);
# 936 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


 
 
 
 
 











int   lr_printf (char * fmt, ...);
 
int   lr_set_debug_message (unsigned int msg_class,
                                       unsigned int swtch);
# 958 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
unsigned int   lr_get_debug_message (void);


 
 
 
 
 

void   lr_double_think_time ( double secs);
void   lr_usleep (long);


 
 
 
 
 
 




int *   lr_localtime (long offset);


int   lr_send_port (long port);


# 1034 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"



struct _lr_declare_identifier{
	char signature[24];
	char value[128];
};

int   lr_pt_abort (void);

void vuser_declaration (void);






# 1063 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"


# 1075 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrun.h"
















 
 
 
 
 







int    _lr_declare_transaction   (char * transaction_name);


 
 
 
 
 







int   _lr_declare_rendezvous  (char * rendezvous_name);

 
 
 
 
 


typedef int PVCI;






typedef int VTCERR;









PVCI   vtc_connect(char * servername, int portnum, int options);
VTCERR   vtc_disconnect(PVCI pvci);
VTCERR   vtc_get_last_error(PVCI pvci);
VTCERR   vtc_query_column(PVCI pvci, char * columnName, int columnIndex, char * *outvalue);
VTCERR   vtc_query_row(PVCI pvci, int rowIndex, char * **outcolumns, char * **outvalues);
VTCERR   vtc_send_message(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_if_unique(PVCI pvci, char * column, char * message, unsigned short *outRc);
VTCERR   vtc_send_row1(PVCI pvci, char * columnNames, char * messages, char * delimiter, unsigned char sendflag, unsigned short *outUpdates);
VTCERR   vtc_update_message(PVCI pvci, char * column, int index , char * message, unsigned short *outRc);
VTCERR   vtc_update_message_ifequals(PVCI pvci, char * columnName, int index,	char * message, char * ifmessage, unsigned short 	*outRc);
VTCERR   vtc_update_row1(PVCI pvci, char * columnNames, int index , char * messages, char * delimiter, unsigned short *outUpdates);
VTCERR   vtc_retrieve_message(PVCI pvci, char * column, char * *outvalue);
VTCERR   vtc_retrieve_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues);
VTCERR   vtc_retrieve_row(PVCI pvci, char * **outcolumns, char * **outvalues);
VTCERR   vtc_rotate_message(PVCI pvci, char * column, char * *outvalue, unsigned char sendflag);
VTCERR   vtc_rotate_messages1(PVCI pvci, char * columnNames, char * delimiter, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_rotate_row(PVCI pvci, char * **outcolumns, char * **outvalues, unsigned char sendflag);
VTCERR   vtc_increment(PVCI pvci, char * column, int index , int incrValue, int *outValue);
VTCERR   vtc_clear_message(PVCI pvci, char * column, int index , unsigned short *outRc);
VTCERR   vtc_clear_column(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_ensure_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_drop_index(PVCI pvci, char * column, unsigned short *outRc);
VTCERR   vtc_clear_row(PVCI pvci, int rowIndex, unsigned short *outRc);
VTCERR   vtc_create_column(PVCI pvci, char * column,unsigned short *outRc);
VTCERR   vtc_column_size(PVCI pvci, char * column, int *size);
void   vtc_free(char * msg);
void   vtc_free_list(char * *msglist);

VTCERR   lrvtc_connect(char * servername, int portnum, int options);
VTCERR   lrvtc_connect_ex(char * vtc_first_param, ...);
VTCERR   lrvtc_connect_ex_no_ellipsis(const char *vtc_first_param, char ** arguments, int argCount);
VTCERR   lrvtc_disconnect();
VTCERR   lrvtc_query_column(char * columnName, int columnIndex);
VTCERR   lrvtc_query_row(int columnIndex);
VTCERR   lrvtc_send_message(char * columnName, char * message);
VTCERR   lrvtc_send_if_unique(char * columnName, char * message);
VTCERR   lrvtc_send_row1(char * columnNames, char * messages, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_update_message(char * columnName, int index , char * message);
VTCERR   lrvtc_update_message_ifequals(char * columnName, int index, char * message, char * ifmessage);
VTCERR   lrvtc_update_row1(char * columnNames, int index , char * messages, char * delimiter);
VTCERR   lrvtc_retrieve_message(char * columnName);
VTCERR   lrvtc_retrieve_messages1(char * columnNames, char * delimiter);
VTCERR   lrvtc_retrieve_row();
VTCERR   lrvtc_rotate_message(char * columnName, unsigned char sendflag);
VTCERR   lrvtc_rotate_messages1(char * columnNames, char * delimiter, unsigned char sendflag);
VTCERR   lrvtc_rotate_row(unsigned char sendflag);
VTCERR   lrvtc_increment(char * columnName, int index , int incrValue);
VTCERR   lrvtc_noop();
VTCERR   lrvtc_clear_message(char * columnName, int index);
VTCERR   lrvtc_clear_column(char * columnName); 
VTCERR   lrvtc_ensure_index(char * columnName); 
VTCERR   lrvtc_drop_index(char * columnName); 
VTCERR   lrvtc_clear_row(int rowIndex);
VTCERR   lrvtc_create_column(char * columnName);
VTCERR   lrvtc_column_size(char * columnName);



 
 
 
 
 

 
int lr_enable_ip_spoofing();
int lr_disable_ip_spoofing();


 




int lr_convert_string_encoding(char * sourceString, char * fromEncoding, char * toEncoding, char * paramName);
int lr_read_file(const char *filename, const char *outputParam, int continueOnError);

int lr_get_char_count(const char * string);


 
int lr_db_connect (char * pFirstArg, ...);
int lr_db_disconnect (char * pFirstArg,	...);
int lr_db_executeSQLStatement (char * pFirstArg, ...);
int lr_db_dataset_action(char * pFirstArg, ...);
int lr_checkpoint(char * pFirstArg,	...);
int lr_db_getvalue(char * pFirstArg, ...);







 
 



















# 1 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h" 1



 
 
 
 
# 100 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/SharedParameter.h"






typedef int PVCI2;






typedef int VTCERR2;


 
 
 

 
extern PVCI2    vtc_connect(char *servername, int portnum, int options);
extern VTCERR2  vtc_disconnect(PVCI2 pvci);
extern VTCERR2  vtc_get_last_error(PVCI2 pvci);

 
extern VTCERR2  vtc_query_column(PVCI2 pvci, char *columnName, int columnIndex, char **outvalue);
extern VTCERR2  vtc_query_row(PVCI2 pvci, int columnIndex, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_send_message(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_if_unique(PVCI2 pvci, char *column, char *message, unsigned short *outRc);
extern VTCERR2  vtc_send_row1(PVCI2 pvci, char *columnNames, char *messages, char *delimiter,  unsigned char sendflag, unsigned short *outUpdates);
extern VTCERR2  vtc_update_message(PVCI2 pvci, char *column, int index , char *message, unsigned short *outRc);
extern VTCERR2  vtc_update_message_ifequals(PVCI2 pvci, char	*columnName, int index,	char *message, char	*ifmessage,	unsigned short 	*outRc);
extern VTCERR2  vtc_update_row1(PVCI2 pvci, char *columnNames, int index , char *messages, char *delimiter, unsigned short *outUpdates);
extern VTCERR2  vtc_retrieve_message(PVCI2 pvci, char *column, char **outvalue);
extern VTCERR2  vtc_retrieve_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues);
extern VTCERR2  vtc_retrieve_row(PVCI2 pvci, char ***outcolumns, char ***outvalues);
extern VTCERR2  vtc_rotate_message(PVCI2 pvci, char *column, char **outvalue, unsigned char sendflag);
extern VTCERR2  vtc_rotate_messages1(PVCI2 pvci, char *columnNames, char *delimiter, char ***outvalues, unsigned char sendflag);
extern VTCERR2  vtc_rotate_row(PVCI2 pvci, char ***outcolumns, char ***outvalues, unsigned char sendflag);
extern VTCERR2	vtc_increment(PVCI2 pvci, char *column, int index , int incrValue, int *outValue);
extern VTCERR2  vtc_clear_message(PVCI2 pvci, char *column, int index , unsigned short *outRc);
extern VTCERR2  vtc_clear_column(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_clear_row(PVCI2 pvci, int rowIndex, unsigned short *outRc);

extern VTCERR2  vtc_create_column(PVCI2 pvci, char *column,unsigned short *outRc);
extern VTCERR2  vtc_column_size(PVCI2 pvci, char *column, int *size);
extern VTCERR2  vtc_ensure_index(PVCI2 pvci, char *column, unsigned short *outRc);
extern VTCERR2  vtc_drop_index(PVCI2 pvci, char *column, unsigned short *outRc);

extern VTCERR2  vtc_noop(PVCI2 pvci);

 
extern void vtc_free(char *msg);
extern void vtc_free_list(char **msglist);

 


 




 




















 




 
 
 

extern VTCERR2  lrvtc_connect(char *servername, int portnum, int options);
 
 
extern VTCERR2  lrvtc_disconnect();
extern VTCERR2  lrvtc_query_column(char *columnName, int columnIndex);
extern VTCERR2  lrvtc_query_row(int columnIndex);
extern VTCERR2  lrvtc_send_message(char *columnName, char *message);
extern VTCERR2  lrvtc_send_if_unique(char *columnName, char *message);
extern VTCERR2  lrvtc_send_row1(char *columnNames, char *messages, char *delimiter,  unsigned char sendflag);
extern VTCERR2  lrvtc_update_message(char *columnName, int index , char *message);
extern VTCERR2  lrvtc_update_message_ifequals(char *columnName, int index, char 	*message, char *ifmessage);
extern VTCERR2  lrvtc_update_row1(char *columnNames, int index , char *messages, char *delimiter);
extern VTCERR2  lrvtc_retrieve_message(char *columnName);
extern VTCERR2  lrvtc_retrieve_messages1(char *columnNames, char *delimiter);
extern VTCERR2  lrvtc_retrieve_row();
extern VTCERR2  lrvtc_rotate_message(char *columnName, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_messages1(char *columnNames, char *delimiter, unsigned char sendflag);
extern VTCERR2  lrvtc_rotate_row(unsigned char sendflag);
extern VTCERR2  lrvtc_increment(char *columnName, int index , int incrValue);
extern VTCERR2  lrvtc_clear_message(char *columnName, int index);
extern VTCERR2  lrvtc_clear_column(char *columnName);
extern VTCERR2  lrvtc_clear_row(int rowIndex);
extern VTCERR2  lrvtc_create_column(char *columnName);
extern VTCERR2  lrvtc_column_size(char *columnName);
extern VTCERR2  lrvtc_ensure_index(char *columnName);
extern VTCERR2  lrvtc_drop_index(char *columnName);

extern VTCERR2  lrvtc_noop();

 
 
 

                               


 
 
 





















# 2 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "globals.h" 1



 
 

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 1







# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h" 1



























































 




 



 











 





















 
 
 

  int
	web_add_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_add_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
	
  int
	web_add_auto_header(
		const char *		mpszHeader,
		const char *		mpszValue);

  int
	web_add_header(
		const char *		mpszHeader,
		const char *		mpszValue);
  int
	web_add_cookie(
		const char *		mpszCookie);
  int
	web_cleanup_auto_headers(void);
  int
	web_cleanup_cookies(void);
  int
	web_concurrent_end(
		const char * const	mpszReserved,
										 
		...								 
	);
  int
	web_concurrent_start(
		const char * const	mpszConcurrentGroupName,
										 
										 
		...								 
										 
	);
  int
	web_create_html_param(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim);
  int
	web_create_html_param_ex(
		const char *		mpszParamName,
		const char *		mpszLeftDelim,
		const char *		mpszRightDelim,
		const char *		mpszNum);
  int
	web_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_custom_request(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_disable_keep_alive(void);
  int
	web_enable_keep_alive(void);
  int
	web_find(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_get_int_property(
		const int			miHttpInfoType);
  int
	web_image(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_image_check(
		const char *		mpszName,
		...);
  int
	web_java_check(
		const char *		mpszName,
		...);
  int
	web_link(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

	
  int
	web_global_verification(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
  int
	web_reg_find(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
				
  int
	web_reg_save_param(
		const char *		mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 

  int
	web_convert_param(
		const char * 		mpszParamName, 
										 
		...);							 
										 
										 


										 

										 
  int
	web_remove_auto_filter(
		const char *		mpszArg,
		...
	);									 
										 
				
  int
	web_remove_auto_header(
		const char *		mpszHeaderName,
		...);							 
										 



  int
	web_remove_cookie(
		const char *		mpszCookie);

  int
	web_save_header(
		const char *		mpszType,	 
		const char *		mpszName);	 
  int
	web_set_certificate(
		const char *		mpszIndex);
  int
	web_set_certificate_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_set_connections_limit(
		const char *		mpszLimit);
  int
	web_set_max_html_param_len(
		const char *		mpszLen);
  int
	web_set_max_retries(
		const char *		mpszMaxRetries);
  int
	web_set_proxy(
		const char *		mpszProxyHost);
  int
	web_set_pac(
		const char *		mpszPacUrl);
  int
	web_set_proxy_bypass(
		const char *		mpszBypass);
  int
	web_set_secure_proxy(
		const char *		mpszProxyHost);
  int
	web_set_sockets_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue
	);
  int
	web_set_option(
		const char *		mpszOptionID,
		const char *		mpszOptionValue,
		...								 
	);
  int
	web_set_timeout(
		const char *		mpszWhat,
		const char *		mpszTimeout);
  int
	web_set_user(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);

  int
	web_sjis_to_euc_param(
		const char *		mpszParamName,
										 
		const char *		mpszParamValSjis);
										 

  int
	web_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	spdy_submit_data(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_submit_form(
		const char *		mpszStepName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										  
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
  int
	web_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	spdy_url(
		const char *		mpszUrlName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_set_proxy_bypass_local(
		const char * mpszNoLocal
		);

  int 
	web_cache_cleanup(void);

  int
	web_create_html_query(
		const char* mpszStartQuery,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int 
	web_create_radio_button_param(
		const char *NameFiled,
		const char *NameAndVal,
		const char *ParamName
		);

  int
	web_convert_from_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 
										
  int
	web_convert_to_formatted(
		const char * mpszArg1,
		...);							 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_ex(
		const char * mpszParamName,
		...);							 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_xpath(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_json(
		const char * mpszParamName,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_regexp(
		 const char * mpszParamName,
		 ...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_reg_save_param_attrib(
		const char * mpszParamName,
		...);
										 
										 
										 
										 
										 
										 
										 		
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_run(
		const char * mpszCode,
		...);							
										 
										 
										 
										 
										 
										 
										 
										 
										 

  int
	web_js_reset(void);

  int
	web_convert_date_param(
		const char * 		mpszParamName,
		...);










# 789 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


# 802 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"



























# 840 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"

 
 
 


  int
	FormSubmit(
		const char *		mpszFormName,
		...);
  int
	InitWebVuser(void);
  int
	SetUser(
		const char *		mpszUserName,
		const char *		mpszPwd,
		const char *		mpszHost);
  int
	TerminateWebVuser(void);
  int
	URL(
		const char *		mpszUrlName);
























# 908 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/as_web.h"


  int
	web_rest(
		const char *		mpszReqestName,
		...);							 
										 
										 
										 
										 

  int
web_stream_open(
	const char *		mpszArg1,
	...
);
  int
	web_stream_wait(
		const char *		mpszArg1,
		...
	);

  int
	web_stream_close(
		const char *		mpszArg1,
		...
	);

  int
web_stream_play(
	const char *		mpszArg1,
	...
	);

  int
web_stream_pause(
	const char *		mpszArg1,
	...
	);

  int
web_stream_seek(
	const char *		mpszArg1,
	...
	);

  int
web_stream_get_param_int(
	const char*			mpszStreamID,
	const int			miStateType
	);

  double
web_stream_get_param_double(
	const char*			mpszStreamID,
	const int			miStateType
	);

  int
web_stream_get_param_string(
	const char*			mpszStreamID,
	const int			miStateType,
	const char*			mpszParameterName
	);

  int
web_stream_set_param_int(
	const char*			mpszStreamID,
	const int			miStateType,
	const int			miStateValue
	);

  int
web_stream_set_param_double(
	const char*			mpszStreamID,
	const int			miStateType,
	const double		mdfStateValue
	);

  int
web_stream_set_custom_mpd(
	const char*			mpszStreamID,
	const char*			aMpdBuf
	);

 
 
 






# 9 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/web_api.h" 2

















 







 















  int
	web_reg_add_cookie(
		const char *		mpszCookie,
		...);							 
										 

  int
	web_report_data_point(
		const char *		mpszEventType,
		const char *		mpszEventName,
		const char *		mpszDataPointName,
		const char *		mpszLAST);	 
										 
										 
										 

  int
	web_text_link(
		const char *		mpszStepName,
		...);

  int
	web_element(
		const char *		mpszStepName,
		...);

  int
	web_image_link(
		const char *		mpszStepName,
		...);

  int
	web_static_image(
		const char *		mpszStepName,
		...);

  int
	web_image_submit(
		const char *		mpszStepName,
		...);

  int
	web_button(
		const char *		mpszStepName,
		...);

  int
	web_edit_field(
		const char *		mpszStepName,
		...);

  int
	web_radio_group(
		const char *		mpszStepName,
		...);

  int
	web_check_box(
		const char *		mpszStepName,
		...);

  int
	web_list(
		const char *		mpszStepName,
		...);

  int
	web_text_area(
		const char *		mpszStepName,
		...);

  int
	web_map_area(
		const char *		mpszStepName,
		...);

  int
	web_eval_java_script(
		const char *		mpszStepName,
		...);

  int
	web_reg_dialog(
		const char *		mpszArg1,
		...);

  int
	web_reg_cross_step_download(
		const char *		mpszArg1,
		...);

  int
	web_browser(
		const char *		mpszStepName,
		...);

  int
	web_control(
		const char *		mpszStepName,
		...);

  int
	web_set_rts_key(
		const char *		mpszArg1,
		...);

  int
	web_save_param_length(
		const char * 		mpszParamName,
		...);

  int
	web_save_timestamp_param(
		const char * 		mpszParamName,
		...);

  int
	web_load_cache(
		const char *		mpszStepName,
		...);							 
										 

  int
	web_dump_cache(
		const char *		mpszStepName,
		...);							 
										 
										 

  int
	web_reg_find_in_log(
		const char *		mpszArg1,
		...);							 
										 
										 

  int
	web_get_sockets_info(
		const char *		mpszArg1,
		...);							 
										 
										 
										 
										 

  int
	web_add_cookie_ex(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

  int
	web_hook_java_script(
		const char *		mpszArg1,
		...);							 
										 
										 
										 

 
 
 
 
 
 
 
 
 
 
 
 
  int
	web_reg_async_attributes(
		const char *		mpszArg,
		...
	);

 
 
 
 
 
 
  int
	web_sync(
		 const char *		mpszArg1,
		 ...
	);

 
 
 
 
  int
	web_stop_async(
		const char *		mpszArg1,
		...
	);

 
 
 
 
 

 
 
 

typedef enum WEB_ASYNC_CB_RC_ENUM_T
{
	WEB_ASYNC_CB_RC_OK,				 

	WEB_ASYNC_CB_RC_ABORT_ASYNC_NOT_ERROR,
	WEB_ASYNC_CB_RC_ABORT_ASYNC_ERROR,
										 
										 
										 
										 
	WEB_ASYNC_CB_RC_ENUM_COUNT
} WEB_ASYNC_CB_RC_ENUM;

 
 
 

typedef enum WEB_CONVERS_CB_CALL_REASON_ENUM_T
{
	WEB_CONVERS_CB_CALL_REASON_BUFFER_RECEIVED,
	WEB_CONVERS_CB_CALL_REASON_END_OF_TASK,

	WEB_CONVERS_CB_CALL_REASON_ENUM_COUNT
} WEB_CONVERS_CB_CALL_REASON_ENUM;

 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 
 

typedef
int														 
	(*RequestCB_t)();

typedef
int														 
	(*ResponseBodyBufferCB_t)(
		  const char *		aLastBufferStr,
		  int				aLastBufferLen,
		  const char *		aAccumulatedStr,
		  int				aAccumulatedLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseCB_t)(
		  const char *		aResponseHeadersStr,
		  int				aResponseHeadersLen,
		  const char *		aResponseBodyStr,
		  int				aResponseBodyLen,
		  int				aHttpStatusCode);

typedef
int														 
	(*ResponseHeadersCB_t)(
		  int				aHttpStatusCode,
		  const char *		aAccumulatedHeadersStr,
		  int				aAccumulatedHeadersLen);



 
 
 

typedef enum WEB_CONVERS_UTIL_RC_ENUM_T
{
	WEB_CONVERS_UTIL_RC_OK,
	WEB_CONVERS_UTIL_RC_CONVERS_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_TASK_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_NOT_FOUND,
	WEB_CONVERS_UTIL_RC_INFO_UNAVIALABLE,
	WEB_CONVERS_UTIL_RC_INVALID_ARGUMENT,

	WEB_CONVERS_UTIL_RC_ENUM_COUNT
} WEB_CONVERS_UTIL_RC_ENUM;

 
 
 

  int					 
	web_util_set_request_url(
		  const char *		aUrlStr);

  int					 
	web_util_set_request_body(
		  const char *		aRequestBodyStr);

  int					 
	web_util_set_formatted_request_body(
		  const char *		aRequestBodyStr);


 
 
 
 
 

 
 
 
 
 

 
 
 
 
 
 
 
 

 
 
  int
web_websocket_connect(
		 const char *	mpszArg1,
		 ...
		 );


 
 
 
 
 																						
  int
web_websocket_send(
	   const char *		mpszArg1,
		...
	   );

 
 
 
 
 
 
  int
web_websocket_close(
		const char *	mpszArg1,
		...
		);

 
typedef
void														
(*OnOpen_t)(
			  const char* connectionID,  
			  const char * responseHeader,  
			  int length  
);

typedef
void														
(*OnMessage_t)(
	  const char* connectionID,  
	  int isbinary,  
	  const char * data,  
	  int length  
	);

typedef
void														
(*OnError_t)(
	  const char* connectionID,  
	  const char * message,  
	  int length  
	);

typedef
void														
(*OnClose_t)(
	  const char* connectionID,  
	  int isClosedByClient,  
	  int code,  
	  const char* reason,  
	  int length  
	 );
 
 
 
 
 





# 7 "globals.h" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/lrw_custom_body.h" 1
 





# 8 "globals.h" 2

# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/time.h" 1

 








# 1 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/stddef.h" 1













typedef unsigned int uintptr_t;








typedef int intptr_t;








typedef int ptrdiff_t;





typedef unsigned short wchar_t;




typedef long time_t;




typedef long clock_t;




typedef wchar_t wint_t;
typedef wchar_t wctype_t;




typedef char *	va_list;



 





# 11 "C:\\Program Files (x86)\\Micro Focus\\LoadRunner\\include/time.h" 2




struct tm
{
  int	tm_sec;
  int	tm_min;
  int	tm_hour;
  int	tm_mday;
  int	tm_mon;
  int	tm_year;
  int	tm_wday;
  int	tm_yday;
  int	tm_isdst;
};








char	  *_asctime_r(struct tm *_tblock, void *_p);


clock_t clock(void);
double	  _difftime32(time_t _time2, time_t _time1);
time_t _mktime32(struct tm *_timeptr);
time_t _time32(time_t *_timer);
char	  *asctime(const struct tm *_tblock);
char	  *_ctime32(const time_t *_time);
struct tm *_gmtime32(const time_t *_timer);
struct tm *_localtime32(const time_t *_timer);
unsigned int   strftime(char *_s, size_t _maxsize, char *_fmt, struct tm *_t);



# 9 "globals.h" 2


 
 


int pmaxValue=0, prandNumber=0;
int GuestFlag=0,LoginFlag=0,AddToCartFlag=0;
int mFound;


char *string_replace(char *input_string,
    char *substring_to_be_replaced,
    char *substitution_string)

 {

 
 char *strstr(const char *s1, const char *s2); 

 
 

char newstring[1024]=""; 

 
 
 

char *str; 

 

char *ptr; 

str = input_string;

 
 

 while((ptr = strstr(input_string, substring_to_be_replaced))!=0)
 {
 input_string = &ptr[strlen(substring_to_be_replaced)];
 ptr[0] = '\0';
 strcat(newstring, str);
 strcat(newstring, substitution_string);
 str = input_string;
 }

 

strcat(newstring, input_string);

return newstring;

 }
 
# 3 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "vuser_init.c" 1
vuser_init()
{
	return 0;
}
# 4 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "UserDetails.c" 1
UserDetails()
{
	return 0;
}
# 5 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "UserDetails_Web.c" 1
UserDetails_Web()
{
	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	
	web_set_max_html_param_len("4024");
	
	web_cache_cleanup();
	web_cleanup_auto_headers();
	web_cleanup_cookies();	
	
	lr_save_string("NO","CTO");
	lr_save_string("NO","Supplies");
	lr_save_string("NO","PDP");
	
	lr_save_string("","AgentType");
	
	lr_start_transaction(lr_eval_string("{AgentType}S60_UniqueVistors"));
	lr_end_transaction(lr_eval_string("{AgentType}S60_UniqueVistors"),2);
	
	GuestFlag=0,LoginFlag=0,mFound=0,pmaxValue=0, prandNumber=0,AddToCartFlag=0;
	
	return 0;
}
# 6 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "UserDetails_Mob.c" 1
UserDetails_Mob()
{
	web_set_sockets_option("SSL_VERSION", "TLS1.2");
	
	web_set_max_html_param_len("1024");
	
	web_cache_cleanup();
	web_cleanup_auto_headers();
	web_cleanup_cookies();	
	
	lr_save_string("NO","CTO");
	lr_save_string("NO","Supplies");
	lr_save_string("NO","PDP");

	web_add_header("User-Agent","{p_mUserAgent}");  
	
	lr_save_string("Mob_","AgentType");
	
	lr_start_transaction(lr_eval_string("{AgentType}S60_UniqueVistors"));
	lr_end_transaction(lr_eval_string("{AgentType}S60_UniqueVistors"),2);
	
	GuestFlag=0,LoginFlag=0,mFound=0,AddToCartFlag=0;
	
	return 0;
}
# 7 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Login_Guest.c" 1
Login_Guest()
{
	int GuestFlag=1;
	
	lr_save_string("","StoreType");
	
	return 0;
}
# 8 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Home.c" 1
Home()
{
	 


	
	int Homei,Homecount;
	
	lr_think_time(60);
	
	web_reg_find("Text=<div class=\"home\">","SaveCount=Home_count","LAST");
	web_save_timestamp_param("cp_time", "LAST");  
	
	lr_start_transaction(lr_eval_string("{AgentType}S00_Homepage"));
		
	lr_start_sub_transaction("S00-1_Homepage",(lr_eval_string("{AgentType}S00_Homepage")));
		
	web_url("HomePage", 
		"URL=https://{p_hostName}/us-en/shop", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_sub_transaction("S00-1_Homepage", 2);
	

	
	web_reg_save_param("cp_ClientID","LB=client_id=","RB=&amp","ORD=1","Notfound=Warning","LAST");
	
	web_url("HPServices_1",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_save_timestamp_param("cp_time", "LAST"); 
	
	 
		
	    web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    

	
	 
	
	
	web_save_timestamp_param("cp_time", "LAST"); 

	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
		
	web_reg_save_param("cp_catentryID","LB=\",\"catentryId\":\"","RB=\",\"","ORD=ALL","Notfound=Warning","LAST");
	
	web_url("async",
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/%2F/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
		
	web_url("product", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/product?itemId={p_ItemId}&limit=12&select=itemId,sku,name,attributes", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");

web_save_timestamp_param("cp_time", "LAST"); 	
		
	lr_start_sub_transaction("S00-2_HPServices",(lr_eval_string("{AgentType}S00_Homepage")));	
	
	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={p_HomeUrl}&modelId=&langId=-1&storeId=10151&catalogId=10051",
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_sub_transaction("S00-2_HPServices", 2);
	
	
	
	

		if(atoi(lr_eval_string("{Home_count}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S00_Homepage"),0);
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S00_Homepage"),1);
			lr_exit(5,1);							
		}
	
	
	return 0;
}
# 9 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CV.c" 1
CV()
{
		 


	
	lr_think_time(30);
	
	web_reg_find("Search=All","SaveCount=c_ContentView","Text=ContentRecommendation_UI.jsp","LAST");
	web_save_timestamp_param("cp_time", "LAST");  
	
	lr_start_transaction(lr_eval_string("{AgentType}S03_ContentView"));
	
	web_url("{p_ContentView}", 
		"URL=https://{p_hostName}/us-en/shop/cv/{p_ContentView}{StoreType}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&pstoreId=&_={cp_time}&action=cupids&catentryId=&modelId=&retainPOCart=false", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cv/{p_ContentView}{StoreType}", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	if((atoi(lr_eval_string("{c_ContentView}"))>0))
	{
		lr_end_transaction(lr_eval_string("{AgentType}S03_ContentView"),0);
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S03_ContentView"),1);
		lr_exit(5,1);
	}
	
	return 0;
}
# 10 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CLP.c" 1
CLP()
{
		 


		
int CLPi,CLPcount;
int CLP1i,CLP1count;

	lr_think_time(30);
	
	web_reg_find("Text=category-landing-page","SaveCount=CLP_Products","LAST");
	
	lr_start_transaction(lr_eval_string("{AgentType}S04_CategoryLanding"));
		lr_start_sub_transaction("S04-1_CategoryLanding",(lr_eval_string("{AgentType}S04_CategoryLanding")));
		
		
	web_url("p_Landing", 
		"URL=https://{p_hostName}/us-en/shop/cat/{p_Landing}",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
		
		lr_end_sub_transaction("S04-1_CategoryLanding", 2);
		
		web_reg_save_param("cp_CLPmodelID1","lb=\"modelId\":\"","rb=\",","ORD=all","LAST");
	web_save_timestamp_param("cp_time", "LAST");		
		
		web_url("sync", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/cat%2F{p_Landing}/sync", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
		
		
		
	CLPcount=atoi(lr_eval_string("{cp_CLPmodelID1_count}"));	
		if(CLPcount == 0)
		{
		
		lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding"),1);
		lr_exit(5,1);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_CLPmodelID1_1}"), "CLPURL");
			for (CLPi=1; CLPi<(lr_paramarr_len("cp_CLPmodelID1")); CLPi++)
			{
				lr_save_string(lr_paramarr_idx("cp_CLPmodelID1", CLPi+1), "CLPCatID");
				lr_save_string(lr_eval_string("{CLPURL},{CLPCatID}"), "CLPURL");
			}
		}
	
	web_url("HPServices_1", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_Landing}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	
		web_save_timestamp_param("cp_time", "LAST");
		
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId=&modelId={CLPURL}&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_Landing}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
		
	

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/cat%2F{p_Landing}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
		
web_save_timestamp_param("cp_time", "LAST");

 
		
	    web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    

	
	 
	
lr_start_sub_transaction("S04-2_HPServices",(lr_eval_string("{AgentType}S04_CategoryLanding")));

	web_url("HPServices_3",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={CLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_Landing}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_sub_transaction("S04-2_HPServices", 2);	
if(atoi(lr_eval_string("{CLP_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding"),0);
		}
		else
		{
		lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding"),1);
		lr_exit(5,1);
		}

		
	return 0;
}
# 11 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CLP_IT.c" 1
CLP_IT()
{
	
int CLPinkToneri,CLPinkTonercount;

	lr_think_time(30);
	
	web_reg_find("Text=category-landing-page","SaveCount=CLPinkToner_Products","LAST");
	web_reg_save_param("cp_CLPinkTonerModelID1","lb=\"modelId\":\"","rb=\",\"","ORD=all","LAST");
	web_save_timestamp_param("cp_time", "LAST");  


	lr_start_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_INK"));
	lr_start_sub_transaction("S04-1_CategoryLanding",(lr_eval_string("{AgentType}S04_CategoryLanding_INK")));
	
	web_url("p_inkTonerProducts", 
		"URL=https://{p_hostName}/us-en/shop/cat/{p_inkTonerProducts}",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_sub_transaction("S04-1_CategoryLanding", 2);
	
	CLPinkTonercount=atoi(lr_eval_string("{cp_CLPinkTonerModelID1_count}"));	
		if(CLPinkTonercount == 0)
		{
			
		lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_INK"),1);
		lr_exit(5,1);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_CLPinkTonerModelID1_1}"), "CLPinkTonerURL1");
			for (CLPinkToneri=1; CLPinkToneri<(lr_paramarr_len("cp_CLPinkTonerModelID1")); CLPinkToneri++)
			{
				lr_save_string(lr_paramarr_idx("cp_CLPinkTonerModelID1", CLPinkToneri+1), "CLPinkTonerCatID");
				lr_save_string(lr_eval_string("{CLPinkTonerURL1},{CLPinkTonerCatID}"), "CLPinkTonerURL1");
			}
		}
	
	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_inkTonerProducts}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	
	
		
	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/cat%2F{p_inkTonerProducts}/async",  
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_inkTonerProducts}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_start_sub_transaction("S04-2_HPServices",(lr_eval_string("{AgentType}S04_CategoryLanding_INK")));
	
	web_url("HPServices_2",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cusipd&catentryId=&modelId={CLPinkTonerURL1}&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_inkTonerProducts}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=ipd&catentryId=&modelId={CLPinkTonerURL1}&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_inkTonerProducts}", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");

	
	lr_end_sub_transaction("S04-2_HPServices", 2);
	
	web_save_timestamp_param("cp_time", "LAST");
	 
		
	    web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    

	
	 
	
	if(atoi(lr_eval_string("{CLPinkToner_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_INK"),0);
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_INK"),1);
			lr_exit(5,1);
		}
	
	return 0;
}
# 12 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CLP_CP.c" 1
CLP_CP()
{
	int CLPcarei,CLPcarecount;
	lr_think_time(30);
	web_reg_save_param("cp_CLPcarepack","lb=\"modelId\":\"","rb=\",\"","ORD=all","LAST");

web_reg_find("Text=category-landing-page","SaveCount=CLPinkToner_Products","LAST");

lr_start_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Carepacks"));
	
	web_url("{p_carepack_products}", 
		"URL=https://{p_hostName}/us-en/shop/cat/{p_carepack_products}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");
		CLPcarecount=atoi(lr_eval_string("{cp_CLPcarepack_count}"));	
		if(CLPcarecount == 0)
		{
			
		lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Carepacks"),1);
		lr_exit(5,1);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_CLPcarepack_1}"), "CLPCareURL");
			for (CLPcarei=1; CLPcarei<(lr_paramarr_len("cp_CLPcarepack")); CLPcarei++)
			{
				lr_save_string(lr_paramarr_idx("cp_CLPcarepack", CLPcarei+1), "CLPcareCatID");
				lr_save_string(lr_eval_string("{CLPCareURL},{CLPcareCatID}"), "CLPCareURL");
			}
		}
		
	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1645774887283&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_carepack_products}", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	 
# 57 "CLP_CP.c"
	web_save_timestamp_param("cp_time", "LAST");
	 
		
	    web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    

	
	 


	web_url("HPServices_5", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1645774888408&action=ipd&catentryId=&modelId={CLPCareURL}&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_carepack_products}", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");

	
		if(atoi(lr_eval_string("{CLPinkToner_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Carepacks"),0);
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Carepacks"),1);
			lr_exit(5,1);
		}

	return 0;
}
# 13 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CLP_AC.c" 1
CLP_AC()
{
		
int CLPARi,CLPARcount;
 
	lr_think_time(30);

web_reg_find("Text=category-landing-page","SaveCount=CLPACC_Products","LAST");

lr_start_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Accessories"));
	web_add_auto_header("Accept-Language", 		"en-US,en;q=0.9");

	web_url("{p_acc_products}", 
		"URL=https://{p_hostName}/us-en/shop/cat/{p_acc_products}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
		
		
		
	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1645780791226&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_acc_products}", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");

 
# 44 "CLP_AC.c"
		
		web_save_timestamp_param("cp_time", "LAST");
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");  
	
	 
	
		
		 
	web_reg_save_param("cp_CLPaccessories","lb=\"catentryId\":\"","rb=\",","ORD=all","Notfound=warning","LAST");
	
		web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/cat%2F{p_acc_products}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
	
 
# 93 "CLP_AC.c"

web_url("HPServices_2",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1645780792682&action=ipd&catentryId=1056168,1085820,1165742,137344,1471802,3074457345618857322,3074457345619612825,3074457345619668320,3074457345619682328,3074457345620001825,3074457345620016819,3074457345620137319&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/cat/{p_acc_products}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	if(atoi(lr_eval_string("{CLPACC_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Accessories"),0);
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S04_CategoryLanding_Accessories"),1);
			lr_exit(5,1);
		}

	return 0;
}
# 14 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "ViewAll.c" 1
ViewAll()
{
		 


	
	int VWAcount,VWAi,randNumber,pmaxValue;
	int viewflag=1;
	char mainfilters[100];
	char mainfilters1[100];
	
	lr_think_time(60);	
	
	web_cache_cleanup();
	web_cleanup_cookies();
	
	web_set_max_html_param_len("9924");
	

	
	web_reg_find("Text=View all items","SaveCount=c_ViewAll","LAST");
	
web_reg_save_param("cp_VWAproductId","lb=\"catentryId\":\"","rb=\",","ord=all","LAST");

	lr_start_transaction(lr_eval_string("{AgentType}S05_ViewAll"));
	lr_start_sub_transaction("S05-1_ViewAll",(lr_eval_string("{AgentType}S05_ViewAll")));

	
	web_url("p_ViewAll",
		"URL=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_sub_transaction("S05-1_ViewAll", 2);
	
	web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");  
	
	 
	
	
	lr_start_sub_transaction("S05-2_HPServices",(lr_eval_string("{AgentType}S05_ViewAll")));
  
	
  	
	web_reg_save_param("main","lb=\"}],\"key\":\"","rb=\"}","ord=all","Notfound=warning","LAST");
	web_reg_save_param("main1","lb=\"displayName\":\"","rb=\",\"displaySequence\":","ord=all","Notfound=warning","LAST");
	web_reg_save_param("main_all","lb=\"facetValue\"","rb=\"displaySequence","ord=all","Notfound=warning","LAST");
	web_reg_save_param("cp_sort","LB=sortDropdown\" value='","RB=\'>","ORD=ALL","Notfound=warning","LAST");
	
	
	web_convert_param("p_viewall1",
	                  "SourceString={p_ViewAll}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/vwa%2F{p_viewall1}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
	
	 
   	 
  
  
  

	lr_save_string(lr_eval_string(mainfilters),"mainfilter");
	lr_save_string(lr_eval_string(mainfilters1),"mainfilter1");
	
	VWAcount=atoi(lr_eval_string("{cp_VWAproductId_count}"));
	if(VWAcount == 0)
	{
		
		lr_end_transaction(lr_eval_string("{AgentType}S05_ViewAll"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{cp_VWAproductId_1}"), "VWAURL");
		for (VWAi=1; VWAi<(lr_paramarr_len("cp_VWAproductId")); VWAi++)
		{
			lr_save_string(lr_paramarr_idx("cp_VWAproductId", VWAi+1), "VWACatID");
			lr_save_string(lr_eval_string("{VWAURL},{VWACatID}"), "VWAURL");
		}
	}
	
	web_save_timestamp_param("cp_time", "LAST"); 
	
		web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={VWAURL}&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t59.inf", 
		"Mode=HTML", 
		"LAST");

web_save_timestamp_param("cp_time", "LAST"); 

	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={VWAURL}&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t63.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_sub_transaction("S05-2_HPServices", 2);
	
	if(atoi(lr_eval_string("{c_ViewAll}"))>0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S05_ViewAll"),0);
	}	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S05_ViewAll"),1);		
		lr_exit(5,1);
	}
	
	web_reg_find("Search=All","SaveCount=c_ProductAvalibility","Text=PRODUCT AVAILABILITY","LAST");
	
	
	web_url("finder-results", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

		
	lr_think_time(30);
	
	 
	
	lr_start_transaction(lr_eval_string("{AgentType}S16_Sorting"));
			
	
	web_reg_save_param("cp_catentryId","lb=\"catentryId\":\"","rb=\",","ord=all","LAST");
	
	web_url("finder-results", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}&orderBy={p_sort}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");	
	
	
	web_url("vwa", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa%2F{p_ViewAll}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}?orderBy={p_sort}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	
	
	VWAcount=atoi(lr_eval_string("{cp_catentryId_count}"));
		if(VWAcount == 0)
		{
			
			lr_end_transaction(lr_eval_string("{AgentType}S16_Sorting"),1);;
		    lr_exit(5,1);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_catentryId_1}"), "VWAURL");
			for (VWAi=1; VWAi<(lr_paramarr_len("cp_catentryId")); VWAi++)
			{
				lr_save_string(lr_paramarr_idx("cp_catentryId", VWAi+1), "VWACatID");
				lr_save_string(lr_eval_string("{VWAURL},{VWACatID}"), "VWAURL");
			}
		}
		
		
		web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1646221538898&action=ipd&catentryId={VWAURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_sort}?orderBy={p_sort}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");


			
	lr_end_transaction(lr_eval_string("{AgentType}S16_Sorting"),2);
	
	
 
 
 
 
 
			
	pmaxValue = atoi(lr_eval_string("{p_randomNum}"));	
	
	if(pmaxValue>0 && pmaxValue<2)
			
	{
		
		
	if(strcmp(lr_eval_string("{cp_subfilter1}"),"")>0 && strcmp(lr_eval_string("{cp_subfilter2}"),"")>0 && strcmp(lr_eval_string("{cp_subfilter3}"),"")>0 && strcmp(lr_eval_string("{cp_subfilter4}"),"") == 0 )
		
	{

		lr_save_string(lr_eval_string("{cp_subfilter1}"), "cp_subfilter4");
	}
	
	else if(strcmp(lr_eval_string("{cp_subfilter1}"),"")>0 && strcmp(lr_eval_string("{cp_subfilter2}"),"")>0 && strcmp(lr_eval_string("{cp_subfilter3}"),"")== 0 && strcmp(lr_eval_string("{cp_subfilter4}"),"") == 0 )
		
	{
		lr_save_string(lr_eval_string("{cp_subfilter2}"), "cp_subfilter3");
		lr_save_string(lr_eval_string("{cp_subfilter1}"), "cp_subfilter4");
	}
	

	lr_save_string(lr_eval_string(lr_eval_string("{cp_subfilter{p_vwarand}}")), "cp_subfilter");
	

	lr_start_transaction(lr_eval_string("{AgentType}S14_Filtering_VWA"));
	
	
	web_url("finder-results", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}%2FPrice%3D800-1000&orderBy={p_sort}", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/business-solutions/Price=800-1000?orderBy={p_sort}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	

	
	web_url("vwa", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa%2F{p_ViewAll}%2FPrice%3D800-1000", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/Price=800-1000?orderBy={p_sort}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1646221538898&action=ipd&catentryId={VWAURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/Price=800-1000?orderBy={p_sort}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");


	lr_end_transaction(lr_eval_string("{AgentType}S14_Filtering_VWA"),2);
	
	
	
	lr_start_transaction(lr_eval_string("{AgentType}S14_MultiFiltering_VWA"));
	
	
	web_url("finder-results", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}%2FPrice%3D800-1000%3Bordr%3DReady-to-Ship&orderBy={p_sort}",	
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/Price=800-1000;ordr=Ready-to-Ship?orderBy={p_sort}", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	

	
	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1646221538898&action=ipd&catentryId={VWAURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/Price=800-1000;ordr=Ready-to-Ship?orderBy={p_sort}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");


	lr_end_transaction(lr_eval_string("{AgentType}S14_MultiFiltering_VWA"),2);
					

					
	lr_think_time(10);
	
	if((atoi(lr_eval_string("{c_ProductAvalibility}"))>0))
	{
	
	lr_start_transaction(lr_eval_string("{AgentType}S14_Filtering_VWA_PA"));
	
	
	web_url("finder-results", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}%2Favailability%3DIn-Stock", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/availability=In-Stock", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"LAST");

	
	web_url("vwa", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa%2F{p_ViewAll}%2Favailability%3DIn-Stock", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/vwa/{p_ViewAll}/availability=In-Stock", 
		"Snapshot=t20.inf", 
		"Mode=HTML", 
		"LAST");

	
	
	lr_end_transaction(lr_eval_string("{AgentType}S14_Filtering_VWA_PA"),2);
	
	lr_think_time(10);
	}
	else
	{
		lr_exit(5,2);
	}
				
					
	lr_start_transaction(lr_eval_string("{AgentType}S15_ClearFilters"));
			
	web_url("finder-results_6", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/component/vwa/finder-results?path=vwa%2F{p_ViewAll}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa/{p_ViewAll}", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_url("vwa", 
		"URL=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa/{p_ViewAll}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/wcs/resources/store/10151/seo/vwa?path=vwa/{p_ViewAll}", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	lr_end_transaction(lr_eval_string("{AgentType}S15_ClearFilters"),2);
	
	}
	

	return 0;
}
# 15 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Dealspage.c" 1
Dealspage()
{
	
	lr_think_time(60);
	
	pmaxValue = atoi(lr_eval_string("{p_randomNum}") );	
	
	web_reg_find("Search=All","SaveCount=c_Deals","Text=jsonAvailableDeals","LAST");
	
	web_reg_find("Search=All","SaveCount=c_Home","Text=HomePage.jsp","LAST");
	
	web_save_timestamp_param("cp_time", "LAST");     
	
	
	if ( pmaxValue < 9)
		
	{
		
	
	lr_start_transaction(lr_eval_string("{AgentType}S17_DealsAPI"));
	      
    web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    
    
	
	 
	 
	}
	
	else
		
	{
	 
 lr_start_transaction(lr_eval_string("{AgentType}S17_DealsAPI"));

web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151{StoreType}", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");    


 
	}
 
	
	if((atoi(lr_eval_string("{c_Deals}"))>0) && (atoi(lr_eval_string("{c_Home}"))==0))
	{
		lr_end_transaction(lr_eval_string("{AgentType}S17_DealsAPI"),0);
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S17_DealsAPI"),1);
	}
	return 0;
}
# 16 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "MLP.c" 1
MLP()
{
	
	int MLPi,MLPcount;
	
	lr_think_time(50);
	
	web_reg_find("Text=mlpList","SaveCount=MLP_Products","LAST");
	 
 	web_reg_save_param("cp_MLPmodelID","lb=\"modelId\":\"","rb=\"","ORD=all","Notfound=warning","LAST");
 	web_save_timestamp_param("cp_time", "LAST");  
 
	lr_start_transaction(lr_eval_string("{AgentType}S06_MLP"));
 
 
 
 
 
 
 
 
 
	
	web_url("{P_MLP}", 
		"URL=https://{p_hostName}/us-en/shop/mlp/{P_MLP}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

  
		MLPcount=atoi(lr_eval_string("{cp_MLPmodelID_count}"));	
		if(MLPcount == 0)
		{
			
			lr_end_transaction(lr_eval_string("{AgentType}S06_MLP"),1);
		    lr_exit(5,0);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_MLPmodelID_1}"), "MLPURL");
			for (MLPi=1; MLPi<(lr_paramarr_len("cp_MLPmodelID")); MLPi++)
			{
				lr_save_string(lr_paramarr_idx("cp_MLPmodelID", MLPi+1), "MLPCatID");
				lr_save_string(lr_eval_string("{MLPURL},{MLPCatID}"), "MLPURL");
			}
		}
	

 
 
 
 
 
 
 
 
		
		web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/mlp/{P_MLP}", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");
		
		web_save_timestamp_param("cp_time", "LAST");
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST");  
	
	 
		
		web_url("productSettings", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/component/productSettings", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"LAST");
		
		
		web_convert_param("p_MLP01",
	                  "SourceString={P_MLP}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
		
		web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/mlp%2F{p_MLP01}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
		
		

 
 
 
 
 
 
 
 
 
		
		
		web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId=&modelId={MLPURL}&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/mlp/{P_MLP}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

		
		if(atoi(lr_eval_string("{MLP_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S06_MLP"),0);
				
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S06_MLP"),1);
		
			lr_exit(5,1);		
		}
		

	return 0;
}
# 17 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "MDP.c" 1
MDP()
{
	int MDPi,MDPcount;
	
		lr_think_time(30);
		
	web_reg_find("Text=mdpList","SaveCount=MDP_Products","LAST");
	web_reg_save_param("cp_MDPcatentryID","LB=\",\"catentryId\":\"","RB=\"","ORD=ALL","LAST");
	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"catentryId\":\"(.*?)\",(.*?)\"product_type\":\"STO\",","Notfound=warning", "Group=1","LAST");
	 

	lr_start_transaction(lr_eval_string("{AgentType}S07_MDP"));
 
	web_url("p_MDP", 
		"URL=https://{p_hostName}/us-en/shop/mdp/{p_MDP}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");
	
	MDPcount=atoi(lr_eval_string("{cp_MDPcatentryID_count}"));
		if(MDPcount == 0)
		{
			
		lr_end_transaction("S07_MDP",1);
    	lr_exit(5,1);
	
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_MDPcatentryID_1}"), "MDPURL");
			for (MDPi=1; MDPi<(lr_paramarr_len("cp_MDPcatentryID")); MDPi++)
			{
				lr_save_string(lr_paramarr_idx("cp_MDPcatentryID", MDPi+1), "MDPCatID");
				lr_save_string(lr_eval_string("{MDPURL},{MDPCatID}"), "MDPURL");
			}
		}

	web_convert_param("p_MDP01",
	                  "SourceString={p_MDP}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/vwa%2F{p_MDP01}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/mlp/{p_MDP}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");
		
		web_save_timestamp_param("cp_time", "LAST");
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
		
	web_save_timestamp_param("cp_time", "LAST");
	web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");		
		
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={MDPURL}&modelId=&langId=-1&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/mdp/{p_MDP}", 
		"Snapshot=t22.inf", 
		"Mode=HTML", 
		"LAST");
		
		if(atoi(lr_eval_string("{MDP_Products}"))>0)
		{
			lr_end_transaction(lr_eval_string("{AgentType}S07_MDP"),0);
			AddToCartFlag = 1;
			lr_save_string("_MDP","cartitem");
		}
		else
		{
		lr_end_transaction("S07_MDP",1);
    	lr_exit(5,1);
	
		}
	
	
		
	return 0;
}
# 18 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "SearchByCTO.c" 1
SearchByCTO()

{
	
	
	 


	
	lr_think_time(60);
	
	web_set_max_html_param_len("9024");
	
	lr_start_transaction(lr_eval_string("{AgentType}S09_SearchByCTO"));
	
	
	
	web_reg_save_param("cp_pdpurl","LB=com/us-en/shop/pdp/","RB=\"","Notfound=Warning","LAST");
	 
	
	web_custom_request("autocomplete_2", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/autocomplete", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\",\"ClientData\":{\"Custom\":{},\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"VisitorId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\"},\"DisplayFullResponse\":true,\"Keyword\":\"{p_CTOPartnumber}\"}", 
		"LAST");
	


	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_reg_save_param("cp_catentryid","lb=\"catentryId\":\"","rb=\",","LAST");
	
	web_reg_find("Text=Customize & buy","savecount=C_CTOCount","LAST");
	
	web_url("sync", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_pdpurl}/sync", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_pdpurl}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1662046653068&action=pid&catentryId={cp_catentryid}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");


	 if(strcmp(lr_eval_string("{cp_catentryid}"),"")==0)
	{
		lr_end_transaction(lr_eval_string("S09_SearchByCTO"),0);
		
		lr_exit(5,1);
	}
	
	else
    {
    	lr_end_transaction(lr_eval_string("{AgentType}S09_SearchByCTO"),0);
    }
	
	
	
	
	return 0;
}
# 19 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "SearchBySTO.c" 1
SearchBySTO()
{
	
	 


	lr_think_time(60);
	
		
	web_set_max_html_param_len("99024");
	
	lr_start_transaction(lr_eval_string("{AgentType}S09_SearchBySTO"));
	
	 
	
		
	web_reg_save_param("cp_pdpurl","LB=com/us-en/shop/pdp/","RB=\"","Notfound=Warning","LAST");


	web_custom_request("autocomplete_2", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/autocomplete", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\",\"ClientData\":{\"Custom\":{},\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"VisitorId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\"},\"DisplayFullResponse\":true,\"Keyword\":\"{p_STOPartNumber}\"}", 
		"LAST");
																																																																																	
	web_add_auto_header("Sec-Fetch-Site", 
		"same-origin");

	web_reg_save_param("cp_catentryid","lb=\"catentryId\":\"","rb=\",","LAST");
	
	web_reg_find("Text=Add to cart","savecount=C_PartNumberCount","LAST");
	
	web_url("sync", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_pdpurl}/sync", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_pdpurl}/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1662046653068&action=pid&catentryId={cp_catentryid}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpurl}", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");


	 if(strcmp(lr_eval_string("{cp_catentryid}"),"")==0)
	{
		lr_end_transaction(lr_eval_string("S09_SearchBySTO"),1);
		
		lr_exit(5,1);
	}
	
	 else 
	 	
	
    {
		lr_end_transaction(lr_eval_string("{AgentType}S09_SearchBySTO"),0);
    }
    
	
	return 0;
}
# 20 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "SearchByText.c" 1
SearchByText()
{
	 


	
	int sbti,sbtcount;
	char fspara[200];	
	int si,catcount,fcount,fcount01;	
	int pmaxValue=0, prandNumber=0;
 
   
   
     
    
	
	lr_think_time(60);
	
	web_set_max_html_param_len("99024");
	
	web_reg_find("Search=All","SaveCount=c_Search","Text=SEARCH RESULTS","LAST");
	
	web_reg_find("Search=All","SaveCount=c_Home","Text=HomePage.jsp","LAST");
	
	web_add_auto_header("accept-language",
		"en-US,en;q=0.9");
	
	
	
	lr_start_transaction(lr_eval_string("{AgentType}S09_Search"));
	
			
	web_url("sync", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/sitesearch%2F/sync", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?keyword={p_Search}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");


web_reg_save_param("sbtcatentryid","lb=\"catentry_id\":[\"","rb=\"],","ord=all","LAST");
web_reg_save_param("cp_SortValue","LB=Value\":\"","RB=\",\"IsDefault","ord=ALL","LAST");
web_reg_save_param("cp_facet","LB=,\"Field\":\"","RB=\",\"","ord=ALL","LAST");
web_reg_save_param("cp_facet01","LB=,\"Field\":\"","RB=\",\"","ord=ALL","LAST");

	
	web_reg_find("Search=All","SaveCount=c_PA","Text=PRODUCT AVAILABILITY","LAST");
	
	web_reg_save_param("cp_category","LB=dte_facet_category\":[\"","RB=\"]","ORD=ALL","Notfound=warning","LAST");
	
	
	web_custom_request("search_2", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitorId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");

 
# 88 "SearchByText.c"
		sbtcount=atoi(lr_eval_string("{sbtcatentryid_count}"));
	
	if(sbtcount == 0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S09_Search"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{sbtcatentryid_1}"), "sbtURL");
		for (sbti=1; sbti<(lr_paramarr_len("sbtcatentryid")); sbti++)
		{
			lr_save_string(lr_paramarr_idx("sbtcatentryid", sbti+1), "sbtCatID");
			lr_save_string(lr_eval_string("{sbtURL},{sbtCatID}"), "sbtURL");
		}
	}

	web_save_timestamp_param("cp_time", "LAST");

	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?keyword={p_Search}", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");


	if((atoi(lr_eval_string("{c_Search}"))>0) && (atoi(lr_eval_string("{c_Home}"))==0))
	{
		lr_end_transaction(lr_eval_string("{AgentType}S09_Search"),0);
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S09_Search"),1);		
		lr_exit(5,1);
	}
		
	
	lr_think_time(30);
	
	
	
	fcount=atoi(lr_eval_string("{cp_facet_count}"));
	fcount01=atoi(lr_eval_string("{cp_facet01_count}"));
	
	pmaxValue = atoi(lr_eval_string("{p_randomNum}"));
	
	if(fcount == 0 || fcount01 == 0 )
	{
		lr_exit(5,1);
	}
	
	else if(pmaxValue>0 && pmaxValue<12)
	{
		
		
	if(atoi(lr_eval_string("{cp_category_count}"))>=1)
	{
		
		
		lr_save_string(lr_paramarr_random("cp_category"),"cp_category");
	
	web_reg_save_param("sbtcatentryid","lb=\"catentry_id\":[\"","rb=\"],","ord=all","LAST");
		
	lr_start_transaction(lr_eval_string("{AgentType}S13_ProductCategory"));
	
	web_custom_request("search_4", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t28.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"ClientData\":{\"Custom\":{},\"UserAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36\",\"VisitorId\":\"dcb0a1a2-eb22-4e12-875a-5e3c1b6f2a54\",\"VisitId\":\"395cd5a8-2d7d-4768-b63e-461d94a605d3\"},\"Keyword\":\"{p_Search}\",\"FacetSelections\":{\"dte_facet_category\":[\"{cp_category}\"]},\"query\":\"type:product\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");
	
	
	sbtcount=atoi(lr_eval_string("{sbtcatentryid_count}"));
	
	if(sbtcount == 0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S13_ProductCategory"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{sbtcatentryid_1}"), "sbtURL");
		for (sbti=1; sbti<(lr_paramarr_len("sbtcatentryid")); sbti++)
		{
			lr_save_string(lr_paramarr_idx("sbtcatentryid", sbti+1), "sbtCatID");
			lr_save_string(lr_eval_string("{sbtURL},{sbtCatID}"), "sbtURL");
		}
	}

	web_save_timestamp_param("cp_time", "LAST");

	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=ipd&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?keyword={p_Search}&dte_facet_category={cp_category}", 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");


	lr_end_transaction(lr_eval_string("{AgentType}S13_ProductCategory"),2);
	
	}
	
	
	lr_save_string(lr_paramarr_random("cp_facet"),"cp_facet");
	lr_save_string(lr_paramarr_random("cp_facet01"),"cp_facet01");
	
	web_reg_save_param("cp_facetValue01","LB={cp_facet}\":[\"","RB=\"],\"", "ord=ALL","LAST");
	web_reg_save_param("cp_facetValue02","LB={cp_facet01}\":[\"","RB=\"],\"","ord=ALL","LAST");

	 
	
	web_custom_request("search_2", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t27.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitorId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");
	
	fcount=atoi(lr_eval_string("{cp_facetValue01_count}"));
	fcount01=atoi(lr_eval_string("{cp_facetValue02_count}"));
	
	if(fcount == 0 || fcount01 == 0 )
	{
		lr_exit(5,1);
	}

 
	lr_save_string(lr_paramarr_random("cp_facetValue01"),"cp_facetValue01");
	lr_save_string(lr_paramarr_random("cp_facetValue02"),"cp_facetValue02");
	lr_save_string(lr_paramarr_random("cp_SortValue"),"cp_SortValue");

	
	lr_start_transaction(lr_eval_string("{AgentType}S16_Sorting"));

web_reg_save_param("sbtcatentryid","lb=\"catentry_id\":[\"","rb=\"],","ord=all","LAST");
			
	web_custom_request("search_4",
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitorId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"SortBy\":\"{cp_SortValue}\",\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");

	sbtcount=atoi(lr_eval_string("{sbtcatentryid_count}"));
	
	if(sbtcount == 0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S16_Sorting"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{sbtcatentryid_1}"), "sbtURL");
		for (sbti=1; sbti<(lr_paramarr_len("sbtcatentryid")); sbti++)
		{
			lr_save_string(lr_paramarr_idx("sbtcatentryid", sbti+1), "sbtCatID");
			lr_save_string(lr_eval_string("{sbtURL},{sbtCatID}"), "sbtURL");
		}
	}

	web_save_timestamp_param("cp_time", "LAST");

	web_url("HPServices_5", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?keyword={p_Search}&sort={cp_SortValue}", 
		"Snapshot=t34.inf", 
		"Mode=HTML", 
		"LAST");


	lr_end_transaction(lr_eval_string("{AgentType}S16_Sorting"),2);

	

	lr_start_transaction(lr_eval_string("{AgentType}S14_Filtering_Search"));


web_reg_save_param("sbtcatentryid","lb=\"catentry_id\":[\"","rb=\"],","ord=all","LAST");
	
	web_custom_request("search_8", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"1f8a791c-c3b3-4dfa-8a06-fe1e6b13dee8\",\"VisitorId\":\"5d9be6d3-a7d9-44f6-901f-e4012b169093\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 6.3; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"FacetSelections\":{\"{cp_facet}\":[\"{cp_facetValue01}\"]},\"SortBy\":\"{cp_SortValue}\",\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");

	sbtcount=atoi(lr_eval_string("{sbtcatentryid_count}"));
	
	if(sbtcount == 0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S14_Filtering_Search"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{sbtcatentryid_1}"), "sbtURL");
		for (sbti=1; sbti<(lr_paramarr_len("sbtcatentryid")); sbti++)
		{
			lr_save_string(lr_paramarr_idx("sbtcatentryid", sbti+1), "sbtCatID");
			lr_save_string(lr_eval_string("{sbtURL},{sbtCatID}"), "sbtURL");
		}
	}


	web_save_timestamp_param("cp_time", "LAST");
	
	web_url("HPServices_7", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?{cp_facet}={cp_facetValue01}&keyword={p_Search}&sort={cp_SortValue}", 
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_transaction(lr_eval_string("{AgentType}S14_Filtering_Search"),2);
	
	
	lr_think_time(10);	
	
	if(strcmp(lr_eval_string("{cp_facet}"),lr_eval_string("{cp_facet01}")) == 0)
		
		{
	lr_exit(5,1);
		}


	lr_start_transaction(lr_eval_string("{AgentType}S14_MultiFiltering_Search"));


web_reg_save_param("sbtcatentryid","lb=\"catentry_id\":[\"","rb=\"],","ord=all","LAST");
	
	web_custom_request("search_8", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t41.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"2fa8087b-50af-4655-84ac-6cb481124f9e\",\"VisitorId\":\"167d305c-b8c0-42b7-8fd3-196fcfe5a2d5\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"FacetSelections\":{\"{cp_facet}\":[\"{cp_facetValue01}\"],\"inventory_status\":[\"In Stock\"]},\"SortBy\":\"{cp_SortValue}\",\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");

	sbtcount=atoi(lr_eval_string("{sbtcatentryid_count}"));
	
	if(sbtcount == 0)
	{
		lr_end_transaction(lr_eval_string("{AgentType}S14_MultiFiltering_Search"),1);
		lr_exit(5,1);
	}	
	else
	{
		lr_save_string(lr_eval_string("{sbtcatentryid_1}"), "sbtURL");
		for (sbti=1; sbti<(lr_paramarr_len("sbtcatentryid")); sbti++)
		{
			lr_save_string(lr_paramarr_idx("sbtcatentryid", sbti+1), "sbtCatID");
			lr_save_string(lr_eval_string("{sbtURL},{sbtCatID}"), "sbtURL");
		}
	}


	web_save_timestamp_param("cp_time", "LAST");
	
	web_url("HPServices_7", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		 
		"Referer=https:///us-en/shop/sitesearch?dte_facet_{cp_facet}_type={cp_facetValue01}&{cp_facet01}_status={cp_facetValue02}&keyword={cp_SortValue}",		
		"Snapshot=t42.inf", 
		"Mode=HTML", 
		"LAST");

		lr_end_transaction(lr_eval_string("{AgentType}S14_MultiFiltering_Search"),2);

		lr_think_time(10);	
		
		 
	
	if((atoi(lr_eval_string("{c_PA}"))>0))
	{
		
	lr_start_transaction(lr_eval_string("{AgentType}S14_Filtering_Search_PA"));


	web_custom_request("search_3", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"query\":\"type:product\",\"ClientData\":{\"VisitId\":\"166d27c3-62e7-4835-8145-5c882998a9ff\",\"VisitorId\":\"b9c4a4cb-0fe3-4a15-99e3-4d4817a378aa\",\"UserAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/105.0.0.0 Safari/537.36\",\"Custom\":{}},\"FacetSelections\":{\"inventory_status\":[\"In Stock\"]},\"SortBy\":\"{cp_SortValue}\",\"Keyword\":\"{p_Search}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\"}", 
		"LAST");


	lr_end_transaction(lr_eval_string("{AgentType}S14_Filtering_Search_PA"),2);
	}
	 
	


		lr_think_time(10);			
				
	lr_start_transaction(lr_eval_string("{AgentType}S15_ClearFilters"));
	
	web_custom_request("search_10", 
		"URL=https://searchapi-test.hawksearch.net/api/v2/search", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t52.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"ClientData\":{\"Custom\":{},\"UserAgent\":\"Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/98.0.4758.102 Safari/537.36\",\"VisitorId\":\"dcb0a1a2-eb22-4e12-875a-5e3c1b6f2a54\",\"VisitId\":\"395cd5a8-2d7d-4768-b63e-461d94a605d3\"},\"Keyword\":\"{p_Search}\",\"FacetSelections\":{},\"query\":\"type:product\",\"SortBy\":\"{cp_SortValue}\",\"ClientGuid\":\"cc79148f6e9a47cbbbe8b0e3ae0f6e89\",\"IndexName\":\"etr\"}", 
		"LAST");


	web_save_timestamp_param("cp_time", "LAST");
	
	web_url("HPServices_5", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=ipd&catentryId={sbtURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/sitesearch?keyword={p_Search}", 
		"Snapshot=t53.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	lr_end_transaction(lr_eval_string("{AgentType}S15_ClearFilters"),2);

	}
	else
	{
		lr_exit(5,2);
	}
	
	
	lr_exit(5,2);
	
	pmaxValue=0;
	prandNumber=0;

	return 0;
}
# 21 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "PDP.c" 1
PDP()
{
		 


	
	int pdpi,pdpcount;
	
	lr_think_time(30);	
	
	web_reg_save_param("cp_PDPproductId","LB=\"catentryId\":\"","RB=\",","ORD=ALL","LAST");
	web_reg_find("Text=pdp-details","SaveCount=PDP_Products","LAST");
	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"catentryId\":\"(.*?)\",(.*?)\"product_type\":\"STO\",","Notfound=warning", "Group=1","LAST");
	web_save_timestamp_param("cp_time", "LAST");


	lr_start_transaction(lr_eval_string("{AgentType}S08_PDP"));
	
	 
	
	web_url("p_PDP", 
		"URL=https://{p_hostName}/us-en/shop/pdp/{p_PDP}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

	pdpcount=atoi(lr_eval_string("{cp_PDPproductId_count}"));	
		if(pdpcount == 0)
		{
			
		lr_end_transaction("S08_PDP",1);
    	lr_exit(5,1);
	
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_PDPproductId_1}"), "PDPURL");
			for (pdpi=1; pdpi<(lr_paramarr_len("cp_PDPproductId")); pdpi++)
			{
				lr_save_string(lr_paramarr_idx("cp_PDPproductId", pdpi+1), "PDPCatID");
				lr_save_string(lr_eval_string("{PDPURL},{PDPCatID}"), "PDPURL");
			}
		}

	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");
	
		
	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{p_PDP}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP}", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		"LAST");
		
		
		web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
		
web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051",		
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP}", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"LAST");

		
	mFound = atoi(lr_eval_string("{c_OutOfStock}"));
	
	if(atoi(lr_eval_string("{PDP_Products}"))>0 && mFound == 0)
		
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP"),0);
		 
		lr_save_string("PDP","cartitem");
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP"),1);
		lr_exit(5,1);
	}
	return 0;
}
# 22 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "PDP_CP.c" 1
PDP_CP()
{
	int pdpcpi,pdpcpcount;
	
	lr_think_time(30);	
	
	web_reg_save_param("cp_PDPproductId","LB=\"catentryId\":\"","RB=\",","ORD=ALL","LAST");
	web_reg_find("Text=pdp-details","SaveCount=PDP_Products","LAST");
	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"catentryId\":\"(.*?)\",(.*?)\"product_type\":\"STO\",","Notfound=warning", "Group=1","LAST");
	web_save_timestamp_param("cp_time", "LAST");  


	lr_start_transaction(lr_eval_string("{AgentType}S08_PDP_CP"));
	
	web_url("{p_PDP_CP}", 
		"URL=https://{p_hostName}/us-en/shop/pdp/{p_PDP_CP}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

	pdpcpcount=atoi(lr_eval_string("{cp_PDPproductId_count}"));	
		if(pdpcpcount == 0)
		{
			
		lr_end_transaction("S08_PDP_CP",1);
    	lr_exit(5,1);
	
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_PDPproductId_1}"), "PDPURL");
			for (pdpcpi=1; pdpcpi<(lr_paramarr_len("cp_PDPproductId")); pdpcpi++)
			{
				lr_save_string(lr_paramarr_idx("cp_PDPproductId", pdpcpi+1), "PDPCatID");
				lr_save_string(lr_eval_string("{PDPURL},{PDPCatID}"), "PDPURL");
			}
		}
	
	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_CP}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");

	web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 

	

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{p_PDP_CP}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_CP}", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		"LAST");
		
web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
		
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=ipd&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_CP}", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"LAST");

		
	mFound = atoi(lr_eval_string("{c_OutOfStock}"));
	
	if(atoi(lr_eval_string("{PDP_Products}"))>0)
		
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_CP"),0);
		 
		lr_save_string("","cartitem");
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_CP"),1);
		lr_exit(5,1);
	}
	

	return 0;
}
# 23 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "PDP_Shadow.c" 1
PDP_Shadow()
{
	
	int i,pdpi,pdpcount,shadowcount;
		
	lr_think_time(30);	
	
	web_reg_save_param("cp_PDPproductId","LB=\"catentryId\":\"","RB=\",","ORD=ALL","Notfound=warning","LAST");
	web_reg_save_param("cp_VanityUrl","LB=\"href\":\"https://perf.store.hp.com/us-en/shop/pdp/","RB=\",","ORD=ALL","Notfound=warning","LAST");
	
	web_reg_find("Text=pdp-details","SaveCount=PDP_Products","LAST");
	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"catentryId\":\"(.*?)\",(.*?)\"product_type\":\"STO\",","Notfound=warning", "Group=1","LAST");
	web_save_timestamp_param("cp_time", "LAST");


	lr_start_transaction(lr_eval_string("{AgentType}S08_PDP_Shadow"));
	
	web_url("p_PDP", 
		"URL=https://{p_hostName}/us-en/shop/pdp/{p_PDPShadow}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

	pdpcount=atoi(lr_eval_string("{cp_PDPproductId_count}"));	
		if(pdpcount == 0)
		{
			
		lr_end_transaction("S08_PDP_Shadow",1);
    	lr_exit(5,1);
	
		}	
		else
		{
			lr_save_string(lr_eval_string("{cp_PDPproductId_1}"), "PDPURL");
			for (pdpi=1; pdpi<(lr_paramarr_len("cp_PDPproductId")); pdpi++)
			{
				lr_save_string(lr_paramarr_idx("cp_PDPproductId", pdpi+1), "PDPCatID");
				lr_save_string(lr_eval_string("{PDPURL},{PDPCatID}"), "PDPURL");
			}
		}

	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDPShadow}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");
		
		web_save_timestamp_param("cp_time", "LAST");
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
		
	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{p_PDPShadow}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDPShadow}", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		"LAST");
		
web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={PDPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051",		
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDPShadow}", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"LAST");
		
		

		
	mFound = atoi(lr_eval_string("{c_OutOfStock}"));
	
	if(atoi(lr_eval_string("{PDP_Products}"))>0 || mFound > 0)
		
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_Shadow"),0);
		 
		lr_save_string("PDP","cartitem");
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_Shadow"),1);
		lr_exit(5,1);
	}
	
shadowcount = atoi(lr_eval_string("{cp_VanityUrl_count}"));	
		if(shadowcount > 1)
		{
	

	for (i = 1; i <= shadowcount; i++)
		
	{
	
lr_save_string(lr_paramarr_random("cp_VanityUrl"), "cp_shadowURL");
	
lr_start_transaction("S08_PDP_ShadowSelection");

	web_url("sync", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_shadowURL}/sync", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_shadowURL}", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_shadowURL}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_shadowURL}", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");



	lr_end_transaction("S08_PDP_ShadowSelection", 2);

	}
	}
	
	
	return 0;
}
# 24 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "PDP_Supplies.c" 1
PDP_Supplies()
{
	int PDP_Suppliesi,PDP_Suppliescount;
	
	web_save_timestamp_param("cp_time", "LAST"); 
	
	lr_think_time(30);
	
	web_reg_find("Search=All","SaveCount=c_Category1","Text=INK, TONER & PAPER","LAST");
	
	web_reg_find("Search=All","SaveCount=c_Home","Text=HomePage.jsp","LAST");
	web_reg_find("Search=All","SaveCount=c_Category2","Text=pdpSimilarSupplies","LAST");
	
	web_set_option("MaxRedirectionDepth", "0", "LAST");
	
	
	web_reg_save_param("C_PDP_SuppliescategoryId","LB=\"catentryId\":\"","RB=\",","ORD=ALL","LAST");
	web_reg_save_param("cp_catEntryIdAddtocart","LB=\"catentryId\":\"","RB=\",","LAST");
	
lr_start_transaction(lr_eval_string("{AgentType}S08_PDP_Supplies"));
	
	web_url("{p_PDP_Supplies}", 
		"URL=https://{p_hostName}/us-en/shop/pdp/{p_PDP_Supplies}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_set_option("MaxRedirectionDepth", "10", "LAST");

	
	 
	web_reg_find("Search=All","SaveCount=c_Category3","Text=productType\": \"STO\"","LAST");
	
	
		
    PDP_Suppliescount=atoi(lr_eval_string("{C_PDP_SuppliescategoryId_count}"));	
		if(PDP_Suppliescount == 0)
		{
			
			lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_Supplies"),1);			
		    lr_exit(5,1);
			
		}	
		else
		{
			lr_save_string(lr_eval_string("{C_PDP_SuppliescategoryId_1}"), "PDP_SuppliesURL");
			for (PDP_Suppliesi=1; PDP_Suppliesi<(lr_paramarr_len("C_PDP_SuppliescategoryId")); PDP_Suppliesi++)
			{
				lr_save_string(lr_paramarr_idx("C_PDP_SuppliescategoryId", PDP_Suppliesi+1), "PDP_SuppliesCatID");
				lr_save_string(lr_eval_string("{PDP_SuppliesURL}%2c{PDP_SuppliesCatID}"), "PDP_SuppliesURL");
			}
		}
    web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={PDP_SuppliesURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_Supplies}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");
    
		web_save_timestamp_param("cp_time", "LAST");
		
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	
    
		web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{p_PDP_Supplies}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_Supplies}", 
		"Snapshot=t29.inf", 
		"Mode=HTTP", 
		"LAST");
		
		
		web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
		
		web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={PDP_SuppliesURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{p_PDP_Supplies}", 
		"Snapshot=t32.inf", 
		"Mode=HTML", 
		"LAST");
		

	if(PDP_Suppliescount > 0 && (atoi(lr_eval_string("{c_Home}"))==0))
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_Supplies"),0);
		 
		lr_save_string("_Supplies","cartitem");
	}
	
	else
	{
		lr_end_transaction(lr_eval_string("{AgentType}S08_PDP_Supplies"),1);
	}
	return 0;
}
# 25 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "PDP_CTO.c" 1
PDP_CTO()
{
	lr_think_time(30);
	
		web_set_max_html_param_len("9999");
	
		
		if(strcmp(lr_eval_string("{p_PartNumber}"),"")==0 || strcmp(lr_eval_string("{p_MRLastParam}"),"")==0 || strcmp(lr_eval_string("{p_ModelRef}"),"")==0 || strcmp(lr_eval_string("{LeadSku}"),"")==0 || strcmp(lr_eval_string("{FinalarrComponent}"),"")==0 || strcmp(lr_eval_string("{SortedPrimarySku}"),"")==0 || strcmp(lr_eval_string("{FinalarrPriceSku}"),"")==0 || strcmp(lr_eval_string("{p_ConfigSKUS}"),"")==0)
	{
	lr_exit(5,1);
		}
	
	web_convert_param("p_MRLastParam",
	                  "SourceString={p_MRLastParam}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	web_convert_param("p_PartNumber_URL",
	                  "SourceString={p_PartNumber}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	
	web_reg_find("Text={p_PartNumber}","savecount=C_PartNumberCount","LAST");
	web_save_timestamp_param("cp_time", "LAST");
	
	web_convert_param("cp_ModelRefParam","SourceString={p_ModelRef}","SourceEncoding=HTML","TargetEncoding=URL","LAST");
	
	web_reg_save_param("productName","LB=var productName = '","RB=';\r\n","Notfound=warning","LAST");
	web_reg_save_param("cp_CatEntryID","LB=\"catentryId\":\"","RB=\",","LAST");
	web_reg_save_param("cp_PaySessionID","LB=JSESSIONID=0000","RB=:","Notfound=Warning","LAST");
	lr_start_transaction("S08_PDP_CTO");
	
	
	
	web_url("cp_pdpURL", 
		"URL=https://{p_hostName}/us-en/shop/pdp/{cp_pdpURL}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1627102062941&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpURL}", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");

	
	web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	
  
	web_url("async_2", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/pdp%2F{cp_pdpURL}/async", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpURL}", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");
	
web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");

	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pid&catentryId={cp_CatEntryID}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpURL}", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"LAST");


	
		
	if(atoi(lr_eval_string("{C_PartNumberCount}"))>0)
    {
	lr_end_transaction("S08_PDP_CTO",0);
    }
    else
    {
	lr_end_transaction("S08_PDP_CTO",1);
	
    lr_exit(5,1);
    }
	
	
	
	mFound = atoi(lr_eval_string("{c_OutOfStock}"));
	
	if (mFound > 0)
	{
	
		 
		
		lr_exit(5,2);
	
	}
	 else
	 	
	 {
	 
		CTO();
	
	 }
	
	
		
	return 0;
}
# 26 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "CTO.c" 1
CTO()
{
		 


	
web_set_max_html_param_len("999999");
	if(strcmp(lr_eval_string("{cp_CatEntryID}"),"")==0)
	{


lr_exit(5,1);
}
	
	 lr_think_time(15);
	 
	lr_start_transaction("S20_CustomizeAndBuy");
	
	web_reg_find("Search=All","SaveCount=c_CTOWeb","Text=<div class=\"configure\">","LAST");
	
		
	web_set_max_retries ("5");	
	
web_url("ConfigureView", 
		"URL=https://{p_hostName}/us-en/shop/ConfigureView?langId=-1&storeId=10151&catalogId=10051&catEntryId={cp_CatEntryID}&urlLangId=&quantity=1", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/pdp/{cp_pdpURL}", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("async", 
		"URL=https://{p_hostName}/us-en/shop/app/api/web/graphql/page/ConfigureView%3FlangId%3D-1%26storeId%3D10151%26catalogId%3D10051%26catEntryId%3D{cp_CatEntryID}%26urlLangId%3D%26quantity%3D1/async", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json",
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_save_timestamp_param("cp_time", "LAST");
	
	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/ConfigureView?langId=-1&storeId=10151&catalogId=10051&catEntryId={cp_CatEntryID}&urlLangId=&quantity=1", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");

	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	

if(strcmp(lr_eval_string("{cp_SecureKey}"),"")==0 || strcmp(lr_eval_string("{cp_LeadDays}"),"")==0 || strcmp(lr_eval_string("{c_CTOWeb1}"),"0")==0 ||strcmp(lr_eval_string("{c_CTOWeb2}"),"0")==0)
	{
		lr_end_transaction(lr_eval_string("S20_CustomizeAndBuy"),1);
		
		lr_exit(5,1);
	}
	
	web_convert_param("cp_pdpname",
	                  "SourceString={productName}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	
web_convert_param("cp_ConfigSKUS",
	                  "SourceString={p_ConfigSKUS}",
	                  "SourceEncoding=URL",
	                  "TargetEncoding=HTML",
	                  "LAST");
	                  
	            web_convert_param("SortedPrimarySku",
	                  "SourceString={SortedPrimarySku}",
	                  "SourceEncoding=URL",
	                  "TargetEncoding=PLAIN",
	                  "LAST");
	  
	  lr_save_string(string_replace(lr_eval_string("{SortedPrimarySku}"),"#","%23"),"SortedPrimarySku");

 web_reg_save_param("parentPartNum","LB=item\":\"","RB=\"}","LAST");
 
 
	 
	
	 web_custom_request("processconfigurationpicksjson", 
		"URL=https://{p_ctohostName}/SterlingConfigRESTfulWebSvcApp/rest/configs/json/processconfigurationpicksjson?webSvcSessionID=&tokenID=&apiTemplateJSONString=&inJSONString=%7B%22include%22%3A%5B%7B%22clazz%22%3A%22Messages%22%7D%2C%7B%22clazz%22%3A%22Property%22%2C%22name%22%3A%22_isViewable%7C%7C_quantity%7C%7C_rulePick%7C%7CUI%3A+PRE+PICK+GUIDING+TEXT%7C%7CUI%3A+POST+PICK+GUIDING+TEXT%7C%7CUI%3A+SUPPRESS+NONE+SELECTION%7C%7CUI%3A+"
		"REQUIRED%7C%7C_dsku%22%7D%5D%2C%22country%22%3A%22US%22%2C%22currency%22%3A%22USD%22%2C%22language%22%3A%22en%22%2C%22organizationCode%22%3A%22US_Store%22%2C%22path%22%3A%22{cp_ModelRefParam}%22%2C%22picks%22%3A%7B%22pick%22%3A%5B{FinalarrComponent}%5D%7D%2C%22addPick%22%3A%5B%5D%2C%22removePick%22%3A%5B%5D%7D&callback="
		"_jqjsp", 
		"Method=GET", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/ConfigureView?catalogId=10051&urlLangId=&langId=-1&storeId=10151&catEntryId={cp_CatEntryID}&quantity=1", 
		"Snapshot=t452.inf", 
		"LAST");
 
 web_url("HPCTOLeadTimeService", 
		"URL=https://{p_hostName}/webapp/wcs/stores/servlet/HPCTOLeadTimeService?&parentSku={p_PartNumber}&skus={SortedPrimarySku}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/ConfigureView?urlLangId=&catalogId=10051&langId=-1&storeId=10151&catEntryId={cp_CatEntryID}&quantity=1", 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"LAST");
	

	  if(strcmp(lr_eval_string("{parentPartNum}"),"")==0)
	{
		lr_end_transaction(lr_eval_string("S20_CustomizeAndBuy"),1);
		
		lr_exit(5,1);
	}
	
	  
	web_reg_save_param("ShipDate","LB=shipDate\": \"","RB=\"}","LAST");

	web_url("getshipdate", 
		"URL=https://{p_ctohostName}/SterlingConfigRESTfulWebSvcApp/rest/configs/json/getshipdate?storeId=10151&webSvcSessionID=&apiTemplateJSONString=&calendarId=CTO-CALENDAR-NB&leadDays=20.0&currentDate={p_CurrentDate}&callback=_ship_id", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"LAST");

	    
	   
	  if(strcmp(lr_eval_string("{ShipDate}"),"")==0)
	{
		lr_end_transaction(lr_eval_string("S20_CustomizeAndBuy"),1);
		
		lr_exit(5,1);
	}
	  
	 	
	  
	  
	web_url("PriceStrikeThroughDynamicKitDisplayCmd", 
		"URL=https://{p_hostName}/webapp/wcs/stores/servlet/PriceStrikeThroughDynamicKitDisplayCmd?storeId=10151&usertype=&catentryId={cp_CatEntryID}&skus={SortedPrimarySku}&crossSell=&pStoreId=&currentDate={p_CurrentDate}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/ConfigureView?langId=-1&storeId=10151&catalogId=10051&catEntryId={cp_CatEntryID}&urlLangId=&quantity=1", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"LAST");

		 
	 if(atoi(lr_eval_string("{c_CTOWeb}"))>0)
    {
	lr_end_transaction("S20_CustomizeAndBuy",0);
    }
    else
    {
	lr_end_transaction("S20_CustomizeAndBuy",1);
	
    lr_exit(5,1);
    }
 
	
	 	web_set_max_html_param_len("1024");
	
	return 0;
}
# 27 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Direct_CTO.c" 1
Direct_CTO()
{
	
	lr_save_string(lr_eval_string("{p_CatEntryID}"), "cp_CatEntryID");
	
	web_set_max_html_param_len("999999");
	
	lr_think_time(15);
	
	if(strcmp(lr_eval_string("{p_PartNumber}"),"")==0 || strcmp(lr_eval_string("{p_MRLastParam}"),"")==0 || strcmp(lr_eval_string("{p_ModelRef}"),"")==0 || strcmp(lr_eval_string("{LeadSku}"),"")==0 || strcmp(lr_eval_string("{FinalarrComponent}"),"")==0 || strcmp(lr_eval_string("{SortedPrimarySku}"),"")==0 || strcmp(lr_eval_string("{FinalarrPriceSku}"),"")==0 || strcmp(lr_eval_string("{p_ConfigSKUS}"),"")==0)
	{
		lr_exit(5,1);
	}
	
	web_convert_param("p_MRLastParam",
	                  "SourceString={p_MRLastParam}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	web_convert_param("p_PartNumber_URL",
	                  "SourceString={p_PartNumber}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
		
	web_convert_param("cp_ModelRefParam",
		              "SourceString={p_ModelRef}",
		              "SourceEncoding=HTML",
		              "TargetEncoding=URL",
		              "LAST");
	
	
	CTO();
	
	return 0;
}
# 28 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "AppStore_SLP.c" 1
AppStore_SLP()
{
		 


	
	int SLPi,SLPcount1,SLPcount;
	
	lr_think_time(10);
	
	web_reg_find("Text=SLPBody","SaveCount=SLP_Products","LAST");
	web_reg_save_param("cp_SLPitemId","LB=\"itemId\":\"","RB=\",","ORD=ALL","LAST");
	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"itemId\":\"(.*?)\",(.*?)\"prdClass\":\"STO\",","Notfound=warning", "Group=1","LAST");
	
	web_save_timestamp_param("cp_time", "LAST");


lr_start_transaction(lr_eval_string("{AgentType}S10_SLP"));

	web_url("p_SLP", 
		"URL=https://{p_hostName}/us-en/shop/slp/{p_SLP}",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
		
SLPcount1=atoi(lr_eval_string("{cp_SLPitemId_count}"));
	if(SLPcount1 == 0)
	{
	
		lr_end_transaction(lr_eval_string(lr_eval_string("{AgentType}S10_SLP")),1);	
		lr_exit(5,1);		
	}	
	else	
		
	{
	lr_save_string(lr_eval_string("{cp_SLPitemId_1}"), "SLPURL");
		for (SLPi=1; SLPi<(lr_paramarr_len("cp_SLPitemId")); SLPi++)
		{
			lr_save_string(lr_paramarr_idx("cp_SLPitemId", SLPi+1), "SLPCatID");
		
			SLPcount=atoi(lr_eval_string("{SLPCatID}"));
						
	if(SLPcount == 0)
	{			
	
	}
	else
	{
	

lr_save_string(lr_eval_string("{SLPURL},{SLPCatID}"), "SLPURL");				
	}
		}		
	}
	
	web_url("HPServices_1", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051",  
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/slp/{p_SLP}", 
		"Snapshot=t24.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_save_timestamp_param("cp_time", "LAST");
	 
		
 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	
	web_save_timestamp_param("cp_time", "LAST");
	web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cusipd&catentryId={SLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/slp/{p_SLP}", 
		"Snapshot=t36.inf", 
		"Mode=HTML", 
		"LAST");

	
	if(atoi(lr_eval_string("{SLP_Products}"))>0)
		{
		lr_end_transaction(lr_eval_string("{AgentType}S10_SLP"),0);
		AddToCartFlag = 1;
		lr_save_string("_SLP","cartitem");
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S10_SLP"),1);
			lr_exit(5,1);
		}


	return 0;
}
# 29 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "AppStore_DLP.c" 1
AppStore_DLP()
{
	 


	
	int DLPi,DLPcount1;
	
	lr_think_time(10);
	
	web_reg_find("Search=All","SaveCount=c_DLP1","Text=dlp-product-list","LAST");
	web_reg_save_param("cp_ModelName","LB=tags\":[\"","RB=\"],","ORD=ALL","LAST");
	web_reg_save_param("cp_DLPcatentryId","lb=\"itemId\":\"","rb=\",","ord=all","LAST");
	
	
lr_start_transaction(lr_eval_string("{AgentType}S10_DLP"));

	web_url("{p_DLP}", 
		"URL=https://{p_hostName}/us-en/shop/dlp/{p_DLP}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
		
DLPcount1=atoi(lr_eval_string("{cp_DLPcatentryId_count}"));
	if(DLPcount1 == 0)
	{
	
		lr_end_transaction(lr_eval_string(lr_eval_string("{AgentType}S10_DLP")),1);	
		lr_exit(5,1);		
	}	
	else	
		
	{
	lr_save_string(lr_eval_string("{cp_DLPcatentryId_1}"), "DLPURL");
		for (DLPi=1; DLPi<(lr_paramarr_len("cp_DLPcatentryId")); DLPi++)
		{
			lr_save_string(lr_paramarr_idx("cp_DLPcatentryId", DLPi+1), "DLPCatID");
			lr_save_string(lr_eval_string("{DLPURL},{DLPCatID}"), "DLPURL");
		}
		
	}

web_save_timestamp_param("cp_time", "LAST"); 


	web_url("HPServices_1",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={DLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/dlp/{p_DLP}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");
	
web_save_timestamp_param("cp_time", "LAST"); 
	
	web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");
	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={DLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/dlp/{p_DLP}", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");
		
	web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	
	
	if(atoi(lr_eval_string("{c_DLP1}"))>0)
		{
		lr_end_transaction(lr_eval_string("{AgentType}S10_DLP"),0);
		 
		 
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S10_DLP"),1);
			lr_exit(5,1);
		}


	return 0;
}
# 30 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "AppStore_PLP.c" 1
AppStore_PLP()

{
	
	 



	int PLPi,PLPcount1;
	
	lr_think_time(10);


	web_reg_save_param_regexp("ParamName=cp_catEntryIdAddtocart","RegExp=\"itemId\":\"(.*?)\",(.*?)\"prdClass\":\"STO\",","Notfound=warning", "Group=1","LAST");
	web_save_timestamp_param("cp_time", "LAST");  
	web_reg_save_param("cp_PLPcatentryId","lb=\"itemId\":\"","rb=\",","ord=all","LAST");
	web_reg_find("Text=plp-root","SaveCount=PLP_Products","LAST");

lr_start_transaction(lr_eval_string("{AgentType}S11_PLP"));

	web_url("{p_PLP}", 
		"URL=http://{p_hostName}/us-en/shop/plp/{p_PLP}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
		
PLPcount1=atoi(lr_eval_string("{cp_PLPcatentryId_count}"));
	if(PLPcount1 == 0)
	{
	
		lr_end_transaction(lr_eval_string(lr_eval_string("{AgentType}S11_PLP")),1);	
		lr_exit(5,1);		
	}	
	else	
		
	{
	lr_save_string(lr_eval_string("{cp_PLPcatentryId_1}"), "PLPURL");
		for (PLPi=1; PLPi<(lr_paramarr_len("cp_PLPcatentryId")); PLPi++)
		{
			lr_save_string(lr_paramarr_idx("cp_PLPcatentryId", PLPi+1), "PLPCatID");
			lr_save_string(lr_eval_string("{PLPURL},{PLPCatID}"), "PLPURL");
		}
		
	}
		
	web_save_timestamp_param("cp_time", "LAST");	
	
	web_url("HPServices",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cupids&catentryId={PLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/plp/{p_PLP}", 
		"Snapshot=t2.inf", 
		"Mode=HTML", 
		"LAST");

	web_save_timestamp_param("cp_time", "LAST");
	 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
	
	 
	
	web_save_timestamp_param("cp_time", "LAST");
	
	web_reg_find("Text=\"lowStock\": true", "SaveCount=c_OutOfStock", "LAST");

	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cusipds&catentryId={PLPURL}&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/plp/{p_PLP}", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	if(atoi(lr_eval_string("{PLP_Products}"))>0)
		{
		lr_end_transaction(lr_eval_string("{AgentType}S11_PLP"),0);
		AddToCartFlag = 1;
					
		lr_save_string("3074457345619560337","cp_catEntryIdAddtocart");
		lr_save_string("_PLP","cartitem");
		}
		else
		{
			lr_end_transaction(lr_eval_string("{AgentType}S11_PLP"),1);
			lr_exit(5,1);
		}


	return 0;
}
# 31 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "AppStore_TechTakes.c" 1
AppStore_TechTakes()
{
	
	 


	
	web_reg_find("Text=hp-tech-takes-title","SaveCount=TechTakes_Products","LAST");
	
	lr_think_time(10);

	lr_start_transaction("S12_TechTakes");

	web_url("{p_TechTakes}", 
		"URL=https://{p_hostName}/us-en/shop/tech-takes/{p_TechTakes}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_url("{p_TechTakes}_2", 
		"URL=https://{p_hostName}/us-en/shop/tech-takes/{p_TechTakes}?deferState=true", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/tech-takes/{p_TechTakes}", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");

	
web_save_timestamp_param("cp_time", "LAST");

	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=cus&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/tech-takes/{p_TechTakes}", 
		"Snapshot=t16.inf", 
		"Mode=HTML", 
		"LAST");
		
		web_save_timestamp_param("cp_time", "LAST");
		 
		
	 web_url("dealsapi", 
        "URL=https://{p_hostName}/webapp/wcs/stores/servlet/DealsAPI?catalogId=10051&langId=-1&storeId=10151", 
        "Resource=0", 
        "RecContentType=application/json", 
        "Referer=https://{p_hostName}/us-en/shop", 
        "Snapshot=t28.inf", 
        "Mode=HTTP", 
        "LAST"); 
		
	 


	
	if(atoi(lr_eval_string("{TechTakes_Products}"))>0)
		{
			lr_end_transaction("S12_TechTakes",0);
			
		}
		else
		{
			lr_end_transaction("S12_TechTakes",0);
			
		}

	return 0;
}
# 32 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Mob_AddToCart_CTO.c" 1
Mob_AddToCart_CTO()
{
	int pdpcpi,pdpcpcount;
	
	lr_think_time(30);
	
	web_add_header("User-Agent","{p_mUserAgent}"); 

	web_set_max_html_param_len("9999");
	
	web_reg_find("Text=Official Site","SaveCount=PDPCount","LAST" );
	
	web_reg_save_param("cp_CatEntryID","LB=\"catentryId\":\"","RB=\"","NotFound=Warning","LAST");	
	web_reg_save_param("cp_PartNum","LB=\"sku\":\"","RB=\"","NotFound=Warning","LAST");
	web_set_option("MaxRedirectionDepth", "0", "LAST");

	lr_start_transaction("S08_MoB_PDP");

	web_url("PDP_page", 
		"URL=https://{p_hostName}/us-en/shop/{p_Mobpdpurl}", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_set_option("MaxRedirectionDepth", "10", "LAST");
	
	web_save_timestamp_param("cp_time", "LAST");
	
	if(strcmp(lr_eval_string("{cp_CatEntryID}"),"")==0 )
		{
			
		lr_end_transaction("S08_MoB_PDP",1);
    	lr_exit(5,1);
	
		}	
		else
		{
	
	web_url("HPServices",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=pids&catentryId={cp_CatEntryID}&modelId=&storeId=10151&catalogId=10051&langId=-1",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{p_hostName}/us-en/shop/{p_Mobpdpurl}",
		"Snapshot=t5.inf",
		"Mode=HTML",
		"LAST");
		
	lr_end_transaction("S08_MoB_PDP",2);
	
	web_reg_find("Search=All","SaveCount=c_orderId1","Text=orderId","LAST");
	
	web_reg_find("Search=All","SaveCount=c_orderItemId1","Text=orderItemId","LAST");
	
	web_reg_save_param("cp_ShipDate","LB=shipDate\": \"","RB=\",", "LAST");	
	
	web_reg_save_param("cp_orderItemId","LB=orderItemId\": [\"","RB=\"],","LAST");	
	web_reg_save_param("cp_orderId","LB=orderId\": [\"","RB=\"],","LAST");	

	lr_start_transaction("S23_Mob_HPCTORestAddToCart_CTO");

	web_submit_data("HPCTORestAddToCartCmd",		
		"Action=https://{p_hostName}/us-en/shop/HPCTORestAddToCartCmd",		
		"Method=POST",
		"TargetFrame=",
		"RecContentType=text/html",
		"Referer=https://{p_hostName}/us-en/shop/{p_Mobpdpurl}",
		"Snapshot=t10.inf",
		"Mode=HTML",
		"ITEMDATA",
		"Name=catentryId", "Value={cp_CatEntryID}", "ENDITEM",
		"LAST");

	
	
	web_reg_save_param("cp_krypto","LB=&krypto=","RB=\"","NotFound=Warning","LAST");
	
	web_convert_param("c_ShipDate",
	                  "SourceString={cp_ShipDate}",
	                  "SourceEncoding=HTML",
	                  "TargetEncoding=URL",
	                  "LAST");
	
	web_convert_param("p_mobpartnum",
	                  "SourceString={p_mobpartnum}",
	                  "SourceEncoding=URL",
	                  "TargetEncoding=HTML",
	                  "LAST");

	web_url("AccessoryAttachView",
		"URL=https://{p_hostName}/us-en/shop/AccessoryAttachView?shipDate={c_ShipDate}&selectedRecommConfig=recConfig1&catEntryId={cp_CatEntryID}&storeId=10151",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{p_hostName}/us-en/shop/{p_Mobpdpurl}",
		"Snapshot=t16.inf",
		"Mode=HTML",
		"LAST");
		
	web_url("HPServices_3",
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=c&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051",
		"TargetFrame=",
		"Resource=0",
		"RecContentType=text/html",
		"Referer=https://{p_hostName}/us-en/shop/AccessoryAttachView?shipDate={c_ShipDate}&selectedRecommConfig=recConfig1&catEntryId={cp_CatEntryID}&storeId=10151",
		"Snapshot=t18.inf",
		"Mode=HTML",
		"LAST");
		
	
	web_url("getconfigurationmodeljson", 
		"URL=https://{p_ctohostName}/SterlingConfigRESTfulWebSvcApp/rest/configs/json/getconfigurationmodeljson?webSvcSessionID=&tokenID=&apiTemplateJSONString=&inJSONString=%7B%22include%22%3A%5B%7B%22clazz%22%3A%22Tab%22%7D%2C%7B%22clazz%22%3A%22Property%22%2C%22name%22%3A%22UI%3A+ICON+GRAPHIC%7C%7CUI%3A+DISPLAY+NAME%7C%7CUI%3A+DEFAULT+SELECTION%7C%7C_description%7C%7CUI%3A+PRODUCT+NAME%7C%7CUI%3A+OPTION+CLASS+VIEW%7C%7CUI%3A+LEAD+"
		"TIME%7C%7CHP_SHIP_DATE_CALENDAR_ID%7C%7CHP_Frogger_Message%7C%7CHP_Frogger_PublishedDate%7C%7CHP_UI_Frogger_DisplayMessage%7C%7CUI%3A+CONTROL%7C%7CUI%3A+SUPPRESS+NONE+SELECTION%7C%7CUI%3A+CONSTANT+GUIDING+TEXT%7C%7C_dsku%7C%7CUI%3A+DISPLAY+ADDITIONAL+"
		"INFO%7C%7C_startdate%7C%7C_enddate%7C%7C_sku%7C%7CHP_CROSSSELL_ITEMS%7C%7CHP_MODEL_HAS_CROSS_SELL%7C%7CHP_CLASS_HAS_CROSS_SELL%22%7D%5D%2C%22country%22%3A%22US%22%2C%22language%22%3A%22en%22%2C%22organizationCode%22%3A%22US_Store%22%2C%22path%22%3A%22US_005FStore%2FStore%2F{p_Mobgetconfig}%22%7D&callback=_jqjsp", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
	
	web_url("HPCTOServices", 
		"URL=https://{p_hostName}/wcs/stores/servlet/HPCTOServices?storeId=10151&langId=-1&parentPartNum={cp_PartNum}&partNumbers=={p_mobpartnum}&fromAttach=true",		
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=https://{p_hostName}/us-en/shop/AccessoryAttachView?shipDate={c_ShipDate}&selectedRecommConfig=recConfig1&catEntryId={cp_CatEntryID}&storeId=10151",
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");
	
	

	if((atoi(lr_eval_string("{c_orderId1}"))>0) && (atoi(lr_eval_string("{c_orderItemId1}"))>0))
	{
		lr_end_transaction("S23_Mob_HPCTORestAddToCart_CTO",0);
	}
	
	else
	{
		lr_end_transaction("S23_Mob_HPCTORestAddToCart_CTO",1);
		lr_exit(5,1);
		
	}
	
	
	lr_think_time(15);
			
	lr_start_transaction("S25_Mob_RemoveCart");
		
	web_submit_data("AjaxOrderChangeServiceItemDelete", 
		"Action=https://{p_hostName}/us-en/shop/AjaxOrderChangeServiceItemDelete", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		 
		"Snapshot=t71.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=orderId", "Value={cp_orderId}", "ENDITEM", 
		"Name=calculationUsage", "Value=-1,-2,-5,-6,-7", "ENDITEM", 
		"Name=check", "Value=*n", "ENDITEM", 
		"Name=orderItemId", "Value={cp_orderItemId}", "ENDITEM", 
		"Name=storeId", "Value=10151", "ENDITEM", 
		"Name=langId", "Value=-1", "ENDITEM", 
		"Name=catalogId", "Value=10051", "ENDITEM", 
		"Name=ccf", "Value=false", "ENDITEM", 
		"Name=cql", "Value=40", "ENDITEM", 
		"Name=cal", "Value=8000", "ENDITEM", 
		"LAST");

	web_url("RefreshCart", 
		"URL=https://{p_hostName}/us-en/shop/RefreshCart?ajax=true&storeId=10151&langId=-1&catalogId=10051&ccf=false&cql=40&cal=8000", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Snapshot=t72.inf", 
		"Mode=HTML", 
		"LAST");
		
	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_={cp_time}&action=c&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051",
		"Resource=0", 
		"RecContentType=text/html", 
		 "Referer=",
		"Snapshot=t54.inf",
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction("S25_Mob_RemoveCart",2);		
		}
		
	return 0;
}
# 33 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "AddToCart.c" 1
AddToCart()
{
	
	int icount1;
	
	
	mFound = atoi(lr_eval_string("{c_OutOfStock}"));
	
		
	pmaxValue = atoi(lr_eval_string("{p_randomNum}") );	
	
if ( AddToCartFlag == 1 && pmaxValue == 1 && mFound == 0)
		
	{
	
		web_reg_save_param("cp_orderId","LB=\"orderId\": [\"","RB=\"","NotFound=Warning","LAST");
	
lr_start_transaction(lr_eval_string("S22_AddToCart{cartitem}"));
	
	web_submit_data("AddToCartAjax",
		"Action=https://{p_hostName}/us-en/shop/AddToCartAjax", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 
		 
		"Snapshot=t13.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=calculationUsage", "Value=-1,-2,-5,-6,-7", "ENDITEM", 
		"Name=inventoryValidation", "Value=true", "ENDITEM", 
		"Name=URL", "Value=", "ENDITEM", 
		"Name=updatePrices", "Value=1", "ENDITEM", 
		"Name=isGC", "Value=N", "ENDITEM",
		"Name=requesttype", "Value=ajax", "ENDITEM", 
		"Name=orderId", "Value=.", "ENDITEM", 
		"Name=langId", "Value=-1", "ENDITEM", 
		"Name=storeId", "Value=10151", "ENDITEM", 
		"Name=catalogId", "Value=10051", "ENDITEM", 
		"Name=catEntryId", "Value={cp_catEntryIdAddtocart}", "ENDITEM", 
		"Name=quantity", "Value=1", "ENDITEM", 
		"LAST");

	
	
	web_url("HPServices_5", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?_=1626157870305&action=c&catentryId=&modelId=&langId=-1&storeId=10151&catalogId=10051", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");



 
# 70 "AddToCart.c"


icount1=atoi(lr_eval_string("{cp_orderId_count}"));
	if(icount1 == 0)
	{
	
		lr_end_transaction(lr_eval_string("S22_AddToCart{cartitem}"),0);	
		lr_exit(5,1);		
	}	
	else	
		
	{
lr_end_transaction(lr_eval_string("S22_AddToCart{cartitem}"),0);

	}
			
	ViewCart();
	

}
	
	
	return 0;
}
# 34 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "ViewCart.c" 1
ViewCart()
{	
	
	int vccount,vci;
	
	web_reg_save_param("cp_CatEntryId","LB=\"sku\":\"","RB=\",","ORD=ALL","LAST");

	web_reg_save_param("cp_krypto","LB=&krypto=","RB=&ddkey","LAST");
	
	
	web_reg_save_param("cp_orderItemId","LB=\"productrow\" id=\"cItem","RB=\">","LAST");
	web_reg_save_param("cp_orderId","LB=\"orderId\" value=\"","RB=\"","LAST");
	
	
	lr_start_transaction("S24_ViewCart");
 
	web_url("OrderCalculate", 
		"URL=https://{p_hostName}/us-en/shop/OrderCalculate?calculationUsageId=-1&catalogId=10051&updatePrices=1&langId=-1&storeId=10151&URL=AjaxOrderItemDisplayView", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/mdp/{p_MDP}", 
		"Snapshot=t17.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	vccount=atoi(lr_eval_string("{cp_CatEntryId_count}"));
	
	if(vccount == 0)
	{
		lr_save_string(lr_eval_string(""),"VCURL");
	}
	else
	{
		lr_save_string(lr_eval_string("{cp_CatEntryId_1}"), "VCURL");
		
		for (vci=1; vci<(lr_paramarr_len("cp_CatEntryId")); vci++)
		{
			lr_save_string(lr_paramarr_idx("cp_CatEntryId", vci+1), "VCCatID");
			
			lr_save_string(lr_eval_string("{VCURL}%2C{VCCatID}"), "VCURL");
		}
	}


	web_url("HPServices_6", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&pstoreId=&_=1626157903514&action=cupids&catentryId={VCURL}&modelId=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t18.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction("S24_ViewCart",2);
	
	
		pmaxValue = atoi(lr_eval_string("{p_randomNum}"));			
	
	if(pmaxValue>0 && pmaxValue<5)
	{
	
		lr_start_transaction("S27_Checkout_Guest");
	
	lr_start_sub_transaction("S27-1_Checkout_Guest_Navigation","S27_Checkout_Guest");
	
	 
		
	web_url("OrderCalculate_2", 
		"URL=https://{p_hostName}/us-en/shop/OrderCalculate?updatePrices=1&shipmentType=single&calculationUsageId=-1&calculationUsageId=-4&calculationUsageId=-6&errorViewName=AjaxOrderItemDisplayView&catalogId=10051&langId=-1&QuoteDisable=N&URL=OrderShippingBillingView&storeId=10151&orderId=.", 
		"Resource=0", 
		"RecContentType=text/html", 
		 
		"Snapshot=t23.inf", 
		"Mode=HTML", 
		"LAST");
	
	 

	web_url("HPServices_4",
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&_=1513772230601&action=cupis&catentryId=&modelId=&retainPOCart=false", 
		"Resource=0", 
		"RecContentType=text/html", 
		 
		"Snapshot=t30.inf", 
		"Mode=HTML", 
		"LAST");
		
	lr_end_sub_transaction("S27-1_Checkout_Guest_Navigation",2);
	
	lr_end_transaction("S27_Checkout_Guest",2);	

	
	
	
	
	}
	
	Removecart();

	

	return 0;
}
# 35 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Removecart.c" 1
Removecart()
{
	
	
	 
	
	lr_start_transaction("S25_RemoveCart");

	
	web_submit_data("AjaxOrderChangeServiceItemDelete",
		"Action=https://{p_hostName}/us-en/shop/AjaxOrderChangeServiceItemDelete", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 	
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=orderId", "Value={cp_orderId}", "ENDITEM", 
		"Name=calculationUsage", "Value=-1,-2,-5,-6,-7", "ENDITEM", 
		"Name=check", "Value=*n", "ENDITEM", 
		"Name=orderItemId", "Value={cp_orderItemId}", "ENDITEM", 
		"Name=storeId", "Value=10151", "ENDITEM", 
		"Name=langId", "Value=-1", "ENDITEM", 
		"Name=catalogId", "Value=10051", "ENDITEM", 
		"Name=ccf", "Value=false", "ENDITEM", 
		"Name=cql", "Value=40", "ENDITEM", 
		"Name=cal", "Value=15000", "ENDITEM", 
		"LAST");

	web_url("RefreshCart", 
		"URL=https://{p_hostName}/us-en/shop/RefreshCart?ajax=true&storeId=10151&langId=-1&catalogId=10051&ccf=false&cql=40&cal=15000", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t9.inf", 
		"Mode=HTML", 
		"LAST");

	
	web_url("HPServices_3", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&pstoreId=&_=1626328453603&action=cupids&catentryId=&modelId=", 
		"TargetFrame=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	web_submit_data("ValidateConfigurationCmd", 
		"Action=https://{p_hostName}/us-en/shop/ValidateConfigurationCmd", 
		"Method=POST", 
		"TargetFrame=", 
		"RecContentType=text/html", 	
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"ITEMDATA", 
		"Name=orderID", "Value={cp_orderId}", "ENDITEM", 
		"Name=isReOrderFlag", "Value=true", "ENDITEM", 
		"Name=storeId", "Value=10151", "ENDITEM", 
		"Name=langId", "Value=-1", "ENDITEM", 
		"Name=catalogId", "Value=10051", "ENDITEM", 
		"Name=ccf", "Value=false", "ENDITEM", 
		"Name=cql", "Value=40", "ENDITEM", 
		"Name=cal", "Value=15000", "ENDITEM", 
		"LAST");
	 
	
	lr_end_transaction("S25_RemoveCart", 2);


	return 0;
}
# 36 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Register_Loyalty.c" 1
Register_Loyalty()
{
	Home();
	
	lr_think_time(30);
	
	lr_start_transaction(lr_eval_string("{AgentType}S36_LoyaltyLanding"));

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_url("LoadLoyaltyLandingPageCmd", 
		"URL=https://{p_hostName}/us-en/shop/LoadLoyaltyLandingPageCmd?catalogId=10051&userTyp=G&storeId=10151", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&pstoreId=&_=1613311917282&action=cupids&catentryId=&modelId=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/LoadLoyaltyLandingPageCmd?catalogId=10051&userTyp=G&storeId=10151", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"LAST");
	
	lr_end_transaction(lr_eval_string("{AgentType}S36_LoyaltyLanding"),2);
	
	 
	
	lr_start_transaction(lr_eval_string("{AgentType}S36_SignUp"));

	web_set_max_html_param_len("764");
		
	web_reg_find("Text=HPID Login", 
		"LAST");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param("cp_AuthLogin","LB=authentication/login/","RB=&target","ORD=1","Notfound=Warning","LAST");

	web_url("authorize", 
		"URL=https://directory.stg.cd.id.hp.com/directory/v1/oauth/authorize?response_type=code&client_id={cp_ClientID}&redirect_uri=https%3A%2F%2F{p_hostName}%2Fwebapp%2Fwcs%2Fstores%2Fservlet%2FETRLogonFlow%3FcatalogId%3D10051%26langId%3D-1%26storeId%3D10151&scope=openid+email+profile+user.profile.write+user.profile.username+user.profile.read+offline_access&state=operation:register&nonce=en&prompt=consent&target=create", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("common.json", 
		"URL=https://login3.stg.cd.id.hp.com/login3/locales/en_US/common.json?v=1.3.28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("countries.json", 
		"URL=https://login3.stg.cd.id.hp.com/login3/locales/en_US/countries.json?v=1.3.28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("X-Requested-With", "ImplicitGen=Yes", "LAST"));

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://login3.stg.cd.id.hp.com");

	web_custom_request("session", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/auth/session", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	web_reg_save_param("cp_CSRFToken","LB=csrfToken\":\"","RB=\"","ORD=1","Notfound=Warning","LAST");
	
	web_reg_save_param("cp_Captcha","LB=arkose\",\"data\":\"","RB=\"","ORD=1","Notfound=Warning","LAST");

	web_custom_request("session_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/auth/session", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"flow\":\"https://directory.stg.cd.id.hp.com/directory/v1/authentication/login/"
		"{cp_AuthLogin}\"}", 
		"LAST");

	web_url("country", 
		"URL=https://static.stg.cd.id.hp.com/login3/country", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("Access-Control-Request-Headers", 
		"csrf-token");

	web_add_auto_header("Access-Control-Request-Method", 
		"GET");

	web_add_auto_header("Origin", 
		"https://login3.stg.cd.id.hp.com");

	web_custom_request("tncs", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sign-up/tncs?locale=en_US&country=IN", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("supported-countries", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sms/supported-countries", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("Access-Control-Request-Headers", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Access-Control-Request-Method", "ImplicitGen=Yes", "LAST"));

	web_add_header("CSRF-TOKEN", 
		"{cp_CSRFToken}");

	web_url("tncs_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sign-up/tncs?locale=en_US&country=IN", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_header("CSRF-TOKEN", 
		"{cp_CSRFToken}");

	web_url("supported-countries_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sms/supported-countries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_cookie("CSRF-TOKEN={cp_CSRFToken}; DOMAIN=login3.stg.cd.id.hp.com");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_url("sign-up", 
		"URL=https://login3.stg.cd.id.hp.com/login3/sign-up", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");


	
	lr_end_transaction(lr_eval_string("{AgentType}S36_SignUp"), 2);

	
	
	web_set_max_html_param_len("1024");
	
	LoginFlag=1;
	
	return 0;
}
# 37 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Register_Guest.c" 1
Register_Guest()
{

	web_set_max_html_param_len("99999");
	

	Home();

	lr_think_time(30);
	
	web_set_max_html_param_len("764");
		
	web_reg_find("Text=HPID Login", 
		"LAST");
	lr_start_transaction(lr_eval_string("{AgentType}S36_Register"));
	
	web_add_header("Upgrade-Insecure-Requests", 
		"1");
	
	web_reg_save_param("cp_AuthLogin","LB=authentication/login/","RB=&target","ORD=1","Notfound=Warning","LAST");

	web_url("authorize", 
		"URL=https://directory.stg.cd.id.hp.com/directory/v1/oauth/authorize?response_type=code&client_id={cp_ClientID}&redirect_uri=https%3A%2F%2F{p_hostName}%2Fwebapp%2Fwcs%2Fstores%2Fservlet%2FETRLogonFlow%3FcatalogId%3D10051%26langId%3D-1%26storeId%3D10151&scope=openid+email+profile+user.profile.write+user.profile.username+user.profile.read+offline_access&state=operation:register&nonce=en&prompt=consent&target=create", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_auto_header("X-Requested-With", 
		"XMLHttpRequest");

	web_url("common.json", 
		"URL=https://login3.stg.cd.id.hp.com/login3/locales/en_US/common.json?v=1.3.28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t4.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("countries.json", 
		"URL=https://login3.stg.cd.id.hp.com/login3/locales/en_US/countries.json?v=1.3.28", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t5.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("X-Requested-With", "ImplicitGen=Yes", "LAST"));

	web_add_header("Access-Control-Request-Headers", 
		"content-type");

	web_add_header("Access-Control-Request-Method", 
		"POST");

	web_add_auto_header("Origin", 
		"https://login3.stg.cd.id.hp.com");

	web_custom_request("session", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/auth/session", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");
	
	
	web_reg_save_param("cp_CSRFToken","LB=csrfToken\":\"","RB=\"","ORD=1","Notfound=Warning","LAST");
	
	web_reg_save_param("cp_Captcha","LB=arkose\",\"data\":\"","RB=\"","ORD=1","Notfound=Warning","LAST");

	web_custom_request("session_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/auth/session", 
		"Method=POST", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"EncType=application/json;charset=UTF-8", 
		"Body={\"flow\":\"https://directory.stg.cd.id.hp.com/directory/v1/authentication/login/"
		"{cp_AuthLogin}\"}", 
		"LAST");

	web_url("country", 
		"URL=https://static.stg.cd.id.hp.com/login3/country", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t8.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_add_auto_header("Access-Control-Request-Headers", 
		"csrf-token");

	web_add_auto_header("Access-Control-Request-Method", 
		"GET");

	web_add_auto_header("Origin", 
		"https://login3.stg.cd.id.hp.com");

	web_custom_request("tncs", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sign-up/tncs?locale=en_US&country=IN", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t10.inf", 
		"Mode=HTML", 
		"LAST");

	web_custom_request("supported-countries", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sms/supported-countries", 
		"Method=OPTIONS", 
		"Resource=0", 
		"Referer=", 
		"Snapshot=t11.inf", 
		"Mode=HTML", 
		"LAST");

	(web_remove_auto_header("Access-Control-Request-Headers", "ImplicitGen=Yes", "LAST"));

	(web_remove_auto_header("Access-Control-Request-Method", "ImplicitGen=Yes", "LAST"));

	web_add_header("CSRF-TOKEN", 
		"{cp_CSRFToken}");

	web_url("tncs_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sign-up/tncs?locale=en_US&country=IN", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t12.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_header("CSRF-TOKEN", 
		"{cp_CSRFToken}");

	web_url("supported-countries_2", 
		"URL=https://ui-backend.stg.cd.id.hp.com/bff/v1/session/sms/supported-countries", 
		"Resource=0", 
		"RecContentType=application/json", 
		"Referer=", 
		"Snapshot=t14.inf", 
		"Mode=HTML", 
		"LAST");

	web_add_cookie("CSRF-TOKEN={cp_CSRFToken}; DOMAIN=login3.stg.cd.id.hp.com");

	(web_remove_auto_header("Origin", "ImplicitGen=Yes", "LAST"));

	web_url("sign-up", 
		"URL=https://login3.stg.cd.id.hp.com/login3/sign-up", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_transaction(lr_eval_string("{AgentType}S36_Register"),2);
	
	
	

	web_set_max_html_param_len("1024");
	
	return 0;
}
# 38 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "MyOrders_Guest.c" 1
MyOrders_Guest()
{
	
	
	Home();
	pmaxValue = atoi(lr_eval_string("{p_randomNum}") );	
	
	if (pmaxValue > 2)
		
	{
		
	web_reg_save_param("cp_krypto","LB=&krypto=","RB=&ddkey", "LAST");
	
	web_reg_save_param("cp_recaptcha","LB=data-sitekey=\"","RB=\"","Notfound=warning","LAST");
	
	lr_start_transaction(lr_eval_string("{AgentType}S55_MyAccountOrders"));
	
	
	web_url("MyAccountOrderStatusView",
		"URL=https://{p_hostName}/us-en/shop/MyAccountOrderStatusView?catalogId=10051&langId=-1&storeId=10151", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t6.inf", 
		"Mode=HTML", 
		"LAST");

	web_url("HPServices", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&_=1598275770946&action=cupids&catentryId=&modelId=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/MyAccountOrderStatusView?catalogId=10051&langId=-1&storeId=10151", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");
	

	lr_end_transaction(lr_eval_string("{AgentType}S55_MyAccountOrders"),2);

		
	lr_start_transaction(lr_eval_string("{AgentType}S56_FindOrder"));
	
	web_add_header("Origin", 
		"https://{p_hostName}");

	web_add_header("Upgrade-Insecure-Requests", 
		"1");

	web_reg_save_param("cp_krypto","LB=&krypto=","RB=&ddkey", "LAST");
	
	
	
	web_url("OrderValidateCmd", 
		"URL=https://{p_hostName}/webapp/wcs/stores/servlet/OrderValidateCmd?storeId=10151&catalogId=10051&URL=/us/en/OrderStatusFinalResultView?catalogId=10051&langId=-1&storeId=10151&ccFlow=Y&OrderId={p_forder}&PhoneNoOrEmail={p_femail}", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=", 
		"Snapshot=t1.inf", 
		"Mode=HTML", 
		"LAST");
	
	
 
# 105 "MyOrders_Guest.c"
web_url("OrderStatusFinalResultView", 
		"URL=https://{p_hostName}/us-en/shop/OrderStatusFinalResultView?storeId=10151&catalogId=10051&krypto={cp_krypto}&ddkey=https%3AOrderValidateCmd", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/MyAccountOrderStatusView?catalogId=10051&langId=-1&storeId=10151", 
		"Snapshot=t7.inf", 
		"Mode=HTML", 
		"LAST");	
	
	
	web_url("HPServices_2", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&_=1598275880056&action=cupids&catentryId=&modelId=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/OrderStatusFinalResultView?catalogId=10051&storeId=10151&krypto={cp_krypto}&ddkey=https%3AOrderValidateCmd", 
		"Snapshot=t15.inf", 
		"Mode=HTML", 
		"LAST");
		
	lr_end_transaction(lr_eval_string("{AgentType}S56_FindOrder"),2);
	}
	return 0;
}
# 39 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "Logout.c" 1
Logout()
{
	
	if(LoginFlag==1)
	{
		
	lr_start_transaction(lr_eval_string("{AgentType}S00_Logout"));

	web_url("Logoff", 
		"URL=https://{p_hostName}/us-en/shop/Logoff?myAcctMain=1&catalogId=10051&langId=-1&deleteCartCookie=true&storeId=10151", 
		"Resource=0", 
		"RecContentType=text/html",  
		"Referer=",
		"Snapshot=t35.inf",
		"Mode=HTML", 
		"LAST");

	web_url("HPServices_4", 
		"URL=https://{p_hostName}/us-en/shop/HPServices?langId=-1&storeId=10151&catalogId=10051&_=1532670903295&action=cupids&catentryId=3074457345618619819%2C3074457345618619818%2C1543651%2C1243165&modelId=", 
		"Resource=0", 
		"RecContentType=text/html", 
		"Referer=https://{p_hostName}/us-en/shop/Logoff?myAcctMain=1&catalogId=10051&langId=-1&deleteCartCookie=true&storeId=10151", 
		"Snapshot=t38.inf", 
		"Mode=HTML", 
		"LAST");

	lr_end_transaction(lr_eval_string("{AgentType}S00_Logout"),2);
	
	}
	
	LoginFlag=0;
	GuestFlag=0;
	return 0;
}
# 40 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

# 1 "vuser_end.c" 1
vuser_end()
{
	return 0;
}
# 41 "e:\\performance\\ecommerce\\etr\\fy23_release\\perf\\scripts\\main\\perftesting_etr_perf\\estore\\etr_navigation_guest\\\\combined_ETR_Navigation_Guest.c" 2

